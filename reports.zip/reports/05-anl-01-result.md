# 05 - ANL-01 Result

## Scope

Chỉ sửa ANL-01 và dependency trực tiếp của Teacher Revenue Analytics.

Không sửa ANL-02, ANL-03, ANL-04 hoặc SYS-01.

Input đã đọc:
- `reports/01-code-inventory.md`
- `reports/02-baseline-build-test.md`
- `reports/03-ui-route-rbac-baseline.md`
- `reports/04-data-root-cause-analysis.md`
- `Codex_ANL_SYS_Maintenance_Kit/prompts/ANL-01.md`

Ghi chú: đường dẫn `prompts/ANL-01.md` ở root không tồn tại; prompt thực tế nằm tại `Codex_ANL_SYS_Maintenance_Kit/prompts/ANL-01.md`.

## Nguyên Nhân

ANL-01 đã có nền tảng đúng: teacher được lấy từ authenticated principal qua `CurrentUserService`, không nhận `teacherId` từ browser, `courseId` được validate ownership trước khi query, và doanh thu chỉ dùng `OrderStatus.PAID`.

Các điểm còn thiếu trong phạm vi yêu cầu lần này:
- KPI chưa có số học viên trả phí từ paid orders.
- API response chưa trả currency rõ ràng cho frontend.
- Frontend format tiền bằng hằng `USD`, chưa lấy từ response.
- Test hiện có chưa khóa đủ các case bắt buộc: teacher không có revenue, pending/failed/cancelled/refunded, nhiều teacher, multi-item order, date range, anonymous.

Policy hiện có được giữ nguyên:
- Doanh thu ANL-01 dùng `OrderItem.unitPrice` theo course ownership.
- Giao dịch thành công được nghiệp vụ công nhận bằng `OrderStatus.PAID`.
- Pending, failed, cancelled và refunded không được tính.
- Refund thành công theo flow hiện có chuyển order sang `REFUNDED`, nên bị loại khỏi analytics.
- Không chuyển source sang `Transaction` vì code nghiệp vụ hiện công nhận paid revenue bằng `Order.status`.

## File Sửa

| File | Thay đổi |
|---|---|
| `src/main/java/com/ojtsu26/elearning/repository/OrderItemRepository.java` | Thêm query `countTeacherPaidStudents()` đếm distinct paid students theo teacher/course/date/status. |
| `src/main/java/com/ojtsu26/elearning/service/impl/TeacherRevenueAnalyticsServiceImpl.java` | Trả thêm `paidStudentCount` và `currency`; vẫn dùng authenticated teacher, `OrderStatus.PAID`, date filter backend, course ownership validation. |
| `src/main/java/com/ojtsu26/elearning/dto/response/TeacherRevenueAnalyticsResponseDTO.java` | Thêm field `currency` và `paidStudentCount`. |
| `src/main/resources/templates/teacher/analytics.html` | Thêm KPI `Paid students`; cập nhật subtitle rõ nghĩa hơn. |
| `src/main/resources/static/js/teacher/analytics.js` | Dùng currency từ API response để format tiền; render KPI paid students. |
| `src/main/resources/static/css/teacher/teacher.css` | Điều chỉnh KPI grid desktop từ 5 sang 6 cột; breakpoint 1024/768/390 vẫn dùng layout responsive hiện có. |
| `src/test/java/com/ojtsu26/elearning/controller/TeacherAnalyticsControllerTest.java` | Mở rộng integration tests cho no revenue, success, pending/failed/cancelled/refunded, two teachers, multi-item, multi-teacher, date range, anonymous/student/IDOR. |
| `src/test/java/com/ojtsu26/elearning/service/TeacherRevenueAnalyticsServiceTest.java` | Cập nhật service test cho `paidStudentCount`, `currency`, và bảo đảm course khác teacher bị chặn trước revenue queries. |

## Cách Sửa

- Giữ một source of truth cho ANL-01 ở backend: `OrderItem` join `Order` và `Course`, filter theo:
  - `c.instructor.id = authenticated teacher id`
  - `o.status = OrderStatus.PAID`
  - `o.createdAt >= from`
  - `o.createdAt < to + 1 day`
  - optional `courseId` sau khi đã validate ownership
- Thêm paid student KPI bằng `count(distinct o.user.id)` trên cùng điều kiện query.
- Giữ paid order count bằng `count(distinct o.id)` để không double count khi một order có nhiều item.
- Frontend chỉ render dữ liệu từ API, không tính doanh thu trong JavaScript.
- Currency format dùng `summary.currency`; hiện trả `USD` vì `OrderServiceImpl` đang lưu `Course.price`, `Order.totalAmount`, `OrderItem.unitPrice` theo USD.

## Test Và Kết Quả

| Lệnh | Kết quả |
|---|---|
| `node --check src\main\resources\static\js\teacher\analytics.js` | PASS |
| `.\mvnw.cmd clean compile` | PASS, `BUILD SUCCESS`, biên dịch lại 326 source files |
| `.\mvnw.cmd "-Dtest=TeacherRevenueAnalyticsServiceTest,TeacherAnalyticsControllerTest" test` | PASS, latest recheck `Tests run: 17, Failures: 0, Errors: 0, Skipped: 0` |
| `.\mvnw.cmd spring-boot:run` | PASS start/shutdown, app chạy trên `127.0.0.1:8080` rồi dừng thủ công |

Coverage ANL-01 đã thêm/cập nhật:
- Teacher không có doanh thu: zero KPI và by-course vẫn trả owned course với revenue 0.
- Payment success: `OrderStatus.PAID` được tính.
- Payment pending/failed/cancelled/refunded: không được tính.
- Hai teacher có dữ liệu riêng.
- Order nhiều item: revenue tính theo item, order/student count dùng distinct để không double count.
- Multi-teacher order: mỗi teacher chỉ thấy item thuộc course của mình.
- Date range xử lý ở backend.
- Anonymous bị `401`.
- Student bị `403`.
- Teacher A đổi `courseId` sang course Teacher B bị `403`.

## UI/Responsive

Template ANL-01 hiện có:
- Tiêu đề rõ ràng.
- Total revenue.
- Paid orders.
- Paid students.
- Enrollments/students.
- Date/course/group filter.
- Revenue chart.
- Course snapshot.
- Revenue by course table/cards.
- Loading, empty, error states.
- Currency format nhất quán từ API response.

CSS đã chỉnh KPI grid cho 6 card:
- Desktop: 6 cột.
- `max-width: 1180px`: 3 cột.
- `max-width: 760px`: 1 cột.

Kiểm tra browser tự động tại 1440/1024/768/390 đã được thử bằng Chrome/Edge headless qua DevTools, nhưng browser process thoát ngay và không giữ được port `9222` (`ECONNREFUSED`). Trong lần recheck mới nhất, Browser plugin nội bộ cũng không có browser session khả dụng (`agent.browsers.list()` trả `[]`). Vì vậy phần responsive runtime không có kết quả browser mới trong môi trường này. Baseline trước đó ở `reports/03-ui-route-rbac-baseline.md` đã xác nhận ANL-01 không overflow/cut/overlap tại 1440/1024/768/390; thay đổi lần này chỉ thêm một KPI card và CSS breakpoint tương ứng.

## Independent Recheck After Latest Change

Date/time: 2026-07-14, Asia/Bangkok.

Scope:
- Rechecked ANL-01 only.
- No ANL-02, ANL-03, ANL-04, or SYS-01 work was performed.
- No new product functionality was added in this recheck.

### Data Recheck

| Case | Result | Evidence |
|---|---|---|
| Teacher without transactions | PASS | `teacherWithoutRevenueGetsZeroKpisAndOwnedCourses()` |
| Teacher with one successful transaction | PASS | `paymentSuccessOrderIsCountedForCurrentTeacherOnly()` |
| Teacher with multiple transactions | PASS | `multiItemOrderCountsItemRevenueWithoutDoubleCountingOrderOrStudent()` and `summaryTrendByCourseAndSourceQueryStayConsistent()` |
| Pending order | PASS, excluded | `pendingFailedCancelledAndRefundedOrdersAreNotCounted()` |
| Failed order | PASS, excluded | `pendingFailedCancelledAndRefundedOrdersAreNotCounted()` |
| Cancelled order | PASS, excluded | `pendingFailedCancelledAndRefundedOrdersAreNotCounted()` |
| Refunded order | PASS, excluded by current policy `OrderStatus.REFUNDED` | `pendingFailedCancelledAndRefundedOrdersAreNotCounted()` |
| Multiple teachers | PASS | `twoTeachersHaveSeparateRevenue()` |
| Order with multiple items | PASS, item revenue is counted; order/student counts use distinct | `multiItemOrderCountsItemRevenueWithoutDoubleCountingOrderOrStudent()` |
| Empty date range | PASS | `dateRangeIsAppliedOnBackend()` |
| First and last day of month | PASS | `monthBoundaryDatesAreInclusiveForFromAndTo()` |

### Consistency Recheck

| Check | Result | Evidence |
|---|---|---|
| KPI total equals source query | PASS | `summaryTrendByCourseAndSourceQueryStayConsistent()` compares API `totalRevenue` to `orderItemRepository.sumTeacherRevenue(...)` |
| Chart DTO total equals KPI/source | PASS | Same test checks trend bucket revenue equals source revenue for the selected range |
| Table/by-course DTO total equals source | PASS | Same test checks by-course revenue split `160.00 + 40.00 = 200.00` |
| Date filter is handled at backend | PASS | `dateRangeIsAppliedOnBackend()` and `monthBoundaryDatesAreInclusiveForFromAndTo()` |

### Security Recheck

| Actor/change | Result | Evidence |
|---|---|---|
| Anonymous | PASS, `401` on API | `anonymousIsUnauthorizedFromTeacherAnalyticsApi()` |
| Student | PASS, `403` on API | `studentRoleIsForbiddenFromTeacherAnalyticsApi()` |
| Teacher A | PASS, sees only own revenue | `paymentSuccessOrderIsCountedForCurrentTeacherOnly()` |
| Teacher B | PASS, separate teacher data | `twoTeachersHaveSeparateRevenue()` |
| Admin | Covered by route security baseline: Admin is not allowed into teacher analytics routes. No production change altered `SecurityConfig`. |
| Changed `courseId` to another teacher's course | PASS, `403` | `teacherCannotFilterByAnotherTeachersCourse()` |
| Changed `teacherId` query param | PASS by design | `TeacherAnalyticsRestController` accepts only `from`, `to`, `groupBy`, and `courseId`; teacher comes from authenticated principal. |

### UI And Static Recheck

| Check | Result | Evidence |
|---|---|---|
| JS syntax | PASS | `node --check src\main\resources\static\js\teacher\analytics.js` |
| Loading state | PASS by static template/JS review | `#analyticsLoading`, `showLoading()` |
| Empty state | PASS by static template/JS review | `#analyticsEmpty`, `renderSummary()` |
| Error state | PASS by static template/JS review | `#analyticsError`, `showError()` |
| Chart duplicate rendering | PASS by static JS review | `renderTrend()` clears `chart.innerHTML = ''` before rendering bars |
| `null`, `undefined`, `NaN` prevention | PASS by static JS review for numeric fields | `asMoney(value)` and `asNumber(value)` coerce empty values to `0`; best course fallback is `None yet` |
| Filter state after submit | PASS in same page | Submit prevents default and keeps current form values while reloading analytics |
| Filter state after full browser reload | NOT PASS / pre-existing behavior | `DOMContentLoaded` always calls `setDefaultDates()` and no URL/local state is read. Not fixed in this pass because it was not caused by the latest ANL-01 change and fixing it would add behavior beyond the current patch. |

Browser/runtime UI note:
- Browser plugin was attempted and returned no available browser sessions (`agent.browsers.list()` returned `[]`).
- Earlier Chrome/Edge headless CDP attempts also failed because the process did not keep port `9222` available (`ECONNREFUSED`).
- Therefore, live UI assertions for 1440px, 1024px, 768px, and 390px could not be completed in this environment during the independent recheck.
- Static CSS review still shows responsive KPI layout: desktop 6 columns, `max-width: 1180px` 3 columns, `max-width: 760px` 1 column.

### Latest Verification Commands

| Command | Result |
|---|---|
| `.\mvnw.cmd "-Dtest=TeacherRevenueAnalyticsServiceTest,TeacherAnalyticsControllerTest" test` | PASS, `Tests run: 17, Failures: 0, Errors: 0, Skipped: 0` |
| `node --check src\main\resources\static\js\teacher\analytics.js` | PASS |
| `.\mvnw.cmd compile` | PASS, `BUILD SUCCESS` |

## Kết Luận

ANL-01 đã được sửa trong phạm vi yêu cầu. Backend không tin `teacherId` từ client, chỉ query course thuộc teacher hiện tại, chỉ tính `PAID`, loại các trạng thái không thành công/refunded theo policy hiện có, và tránh double count order/student khi order có nhiều item.

Không có thay đổi cho ANL-02, ANL-03, ANL-04 hoặc SYS-01.

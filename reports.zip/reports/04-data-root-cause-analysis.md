# 04 - Data Root Cause Analysis for ANL/SYS

## Scope

Analysis only. No application code, database schema, seed data, production password, branch, stash, reset, checkout, commit, or fix was changed.

Date/time: 2026-07-14, Asia/Bangkok.

Input used:
- Previous baseline reports in `reports/00..03`.
- Source code under `src/main/java` and `src/main/resources`.
- Read-only MySQL inspection against local `mock_project`.

Target features:
- ANL-01: Teacher personal revenue analytics.
- ANL-02: Admin overview dashboard.
- ANL-03: Admin new and active students analytics.
- ANL-04: Admin revenue by day/month/year.
- SYS-01: Admin general system settings.

## Executive Summary

Revenue analytics currently use `OrderItem.unitPrice` joined to `Order`, not `Payment` or `Transaction`, and count only `OrderStatus.PAID`. Revenue is recognized by `Order.createdAt`; there is no `paidAt`, `completedAt`, or `Order.updatedAt` on `Order`. Refunds exist and successful refunds set `Order.status = REFUNDED`, so refunded orders are excluded from analytics after the status change.

Teacher revenue identity is derived from the authenticated user through `CurrentUserService`, not from a client-provided `teacherId`. The only client-provided ownership filter is `courseId`, and it is validated against `Course.instructor.id` before querying revenue. This reduces IDOR risk for ANL-01.

New student analytics currently mean `User.role = STUDENT` and `User.createdAt` inside the selected range. There is no separate timestamp for role assignment.

Active student analytics currently mean `LessonProgress.lastAccessedAt` with fallback to `LessonProgress.lastUpdatedAt`. The database has other possible activity signals (`course_enrollments`, `submissions`, `quiz_attempts`), but admin analytics do not use them.

SYS-01 settings are stored in DB table `system_settings`, seeded lazily by `SystemSettingServiceImpl.ensureDefaults()`. Validation exists by setting type. There is no explicit cache layer. Audit is partial: `updated_by` and timestamps are stored, and changes are logged, but there is no immutable history table.

## A. Revenue Analysis

### Source of Revenue

| Question | Finding |
|---|---|
| Revenue comes from `Order`, `Payment`, or `Transaction`? | Analytics sum `OrderItem.unitPrice` joined to `Order`. They do not sum `Transaction.amount`, `Order.totalAmount`, or `Order.paidAmount`. |
| Successful payment status | `OrderStatus.PAID` is the analytics success condition. Payment webhook sets `Order.status = PAID` when provider result code is `0`; transaction is set to `TransactionStatus.SUCCESS`. |
| Revenue timestamp | Analytics use `Order.createdAt`. `Order` has no `paidAt`, `completedAt`, or `updatedAt` field. `Transaction` has `createdAt` and `updatedAt`, but analytics do not use it. |
| Refund support | Yes. `RefundTransaction` exists. `PaymentServiceImpl.refundOrder()` creates refund rows and sets `Order.status = REFUNDED` on successful refund. |
| Cancelled / failed / pending | Enum has `PENDING`, `PAID`, `FAILED`, `EXPIRED`, `CANCELLED`, `REFUNDED`; analytics include only `PAID`. |
| Gross or net | Gross item/course price. No tax, discount, platform fee, or teacher commission is subtracted in analytics. |
| Discount/tax/platform fee | `StudentViewController` has a checkout discount placeholder of zero. `commerce.teacherCommissionRate` exists as a setting but is not used by analytics. No tax/platform fee fields were found in order/order item analytics queries. |
| Multi-item order | Entity supports `Order.items: List<OrderItem>`. `OrderServiceImpl.createOrder()` currently creates exactly one item for one course. Local DB inspection found `multi_item_orders = 0`. |
| Multi-teacher order | Schema supports this indirectly because each `OrderItem` points to a `Course`, and each course has an instructor. Current create flow creates one course per order; local DB inspection found `multi_teacher_orders = 0`. |
| Double-count risk | Revenue sum intentionally counts item-level revenue. Paid order count uses `count(distinct o.id)` for teacher and a set of order IDs in trend buckets, so order count avoids duplicate counting. Revenue would double count only if duplicate `OrderItem` rows exist for the same purchased course/order. |

### Important Files and Methods

| File | Method/query | Role in revenue logic |
|---|---|---|
| `src/main/java/com/ojtsu26/elearning/service/impl/AdminAnalyticsServiceImpl.java` | `getDashboardOverview()`, `getRevenueAnalytics()` | Calls order/order-item repositories with `OrderStatus.PAID`; uses selected date range. |
| `src/main/java/com/ojtsu26/elearning/service/impl/TeacherRevenueAnalyticsServiceImpl.java` | `getRevenueAnalytics()`, `getRevenueByCourse()` | Gets current teacher, validates course ownership, calls teacher-scoped order-item queries. |
| `src/main/java/com/ojtsu26/elearning/repository/OrderItemRepository.java` | `sumPaidRevenue*`, `findPaidRevenueEvents`, `sumTeacherRevenue`, `findTeacherRevenueEvents`, `findTeacherRevenueByCourse` | Revenue source of truth for analytics. |
| `src/main/java/com/ojtsu26/elearning/repository/OrderRepository.java` | `countByStatus*` | Paid order counts. |
| `src/main/java/com/ojtsu26/elearning/service/impl/PaymentServiceImpl.java` | `processWebhook()`, `refundOrder()` | Sets `OrderStatus.PAID`, `FAILED`, and `REFUNDED`. |
| `src/main/java/com/ojtsu26/elearning/model/entity/Order.java` | `createdAt`, `status`, `totalAmount`, `paidAmount`, `items` | Order state and timestamp currently available. |
| `src/main/java/com/ojtsu26/elearning/model/entity/OrderItem.java` | `unitPrice`, `course`, `order` | Analytics revenue amount and course/teacher join point. |

### Data Observations

Read-only local DB inspection:
- `Orders` columns include `created_at`, `expired_at`, `status`, `total_amount`, `paid_amount`, but no `paid_at` or `updated_at`.
- `Transactions` columns include `created_at` and `updated_at`, but analytics do not query them.
- Current local data summary: `orders_total = 20`, `paid_orders = 12`, `refunded_orders = 2`, `failed_orders = 3`, `expired_orders = 3`, `cancelled_orders = 0`, `pending_orders = 0`.
- Current local data has no multi-item or multi-teacher order.

## B. Teacher Revenue Analysis

### Relationship Chain

Actual chain in ANL-01:

`Authenticated Teacher` -> `CurrentUserService.getCurrentUser()` -> `User` with `Role.TEACHER` -> `Course.instructor.id` ownership -> `OrderItem.course` -> `Order.status = PAID` and `Order.createdAt` -> revenue/enrollment DTOs.

Enrollment counts for teacher analytics use `CourseEnrollment.enrolledAt` and `CourseEnrollment.course.instructor.id`, not payment tables.

### IDOR Review

| Client input | Current behavior | IDOR risk |
|---|---|---|
| `teacherId` | Not accepted by `TeacherAnalyticsRestController`. Teacher ID comes from authenticated principal via `CurrentUserService`. | Low |
| `userId` | Not accepted by ANL-01 analytics endpoints. | Low |
| `courseId` | Accepted as optional filter. `TeacherRevenueAnalyticsServiceImpl.requireOwnedCourseIfPresent()` loads the course and checks `course.instructor.id == current teacher id` before revenue query. | Low if validation remains before query |
| Date / groupBy | Accepted from client, normalized and validated. | Not IDOR; validation exists for invalid range/grouping |

Evidence from previous runtime baseline:
- Teacher A calling Teacher B's course (`courseId=1`) received `403 {"message":"You do not have access to this course."}` for both teacher revenue endpoints.

## C. New Student Analysis

Current definition in code:

`new student = User where role == Role.STUDENT and User.createdAt in [from, to)`

Evidence:
- `AdminAnalyticsServiceImpl.getDashboardOverview()` calls `userRepository.countByRoleAndCreatedAtGreaterThanEqualAndCreatedAtLessThan(Role.STUDENT, from, to)`.
- `AdminAnalyticsServiceImpl.getStudentAnalytics()` calls `userRepository.findNewStudentEvents(Role.STUDENT, from, to)`.
- `UserRepository.findNewStudentEvents()` selects `u.id` and `u.createdAt` where `u.role = :studentRole`.

Checked alternatives:

| Possible definition | Evidence found |
|---|---|
| Account creation date | Yes. Current implementation uses `User.createdAt`. |
| Role assignment date | No separate role-assignment timestamp or role history table found. `User.updatedAt` exists but is not used and does not specifically mean role assignment. |
| First enrollment date | `CourseEnrollment.enrolledAt` exists, but admin new-student analytics do not use it. |
| Other rule | No other rule found in ANL-03 code. |

No new definition is proposed here because the code already has an explicit implementation and no separate role-assignment evidence exists.

## D. Active Student Analysis

Current definition in code:

`active student = distinct LessonProgress.enrollment.student.id where coalesce(lastAccessedAt, lastUpdatedAt) in [from, to)`

Evidence:
- `AdminAnalyticsServiceImpl.ACTIVE_STUDENT_METHOD` literally states: `Lesson progress activity using LessonProgress.lastAccessedAt with lastUpdatedAt fallback`.
- `LessonProgressRepository.countActiveStudentsForAnalytics()` uses `count(distinct p.enrollment.student.id)`.
- `LessonProgressRepository.findActiveStudentEventsForAnalytics()` selects `studentId` and `coalesce(p.lastAccessedAt, p.lastUpdatedAt) as occurredAt`.

Database/source availability:

| Source | Exists? | Fields found | Used by ANL-03 active student? | Notes |
|---|---:|---|---:|---|
| `lastLoginAt` on user | No | None found in `User` entity/table | No | No direct login timestamp. |
| Login history table | No | No `%login%` table found | No | Auth login logs to server log only. |
| Activity log/event table | No general learner activity table found | Blog moderation log tables exist but are unrelated | No | Not suitable for student activity analytics. |
| Lesson progress | Yes | `last_accessed_at`, `last_updated_at`, `completed_at` | Yes | Current source of truth. |
| Enrollment activity | Yes | `course_enrollments.enrolled_at` | No | Could indicate enrollment but not learning activity. |
| Quiz submission | Yes | `quiz_attempts.started_at`, `submitted_at`, `updated_at` | No | Could be a secondary signal but not used now. |
| Assignment submission | Yes | `submissions.submitted_at`, `updated_at` | No | Could be a secondary signal but not used now. |
| Event/audit table | Partial/unrelated | Blog moderation logs, notifications | No | Not a learner activity event stream. |

Root risk:
- Students who are active only by quiz attempts/submissions/enrollment but without `LessonProgress.lastAccessedAt/lastUpdatedAt` in range are not counted as active.
- `lastUpdatedAt` fallback may count system updates to progress rows as activity even if no explicit learner access happened.

## E. SYS-01 Analysis

### Storage and Defaults

| Question | Finding |
|---|---|
| Stored in DB or properties? | DB table `system_settings`. Defaults are defined in code by `SystemSettingServiceImpl.defaultSettings()` and inserted lazily by `ensureDefaults()`. |
| Entity/table | Entity `SystemSetting`; physical table `system_settings` in local MySQL. |
| Setting types | `STRING`, `BOOLEAN`, `INTEGER`, `DECIMAL`, `EMAIL`. |
| Current default keys | `site.name`, `site.maintenanceMode`, `site.supportEmail`, `commerce.currency`, `commerce.teacherCommissionRate`, `learning.defaultEnrollmentStatus`. |
| Editable keys | Current defaults are inserted with `editable = true`. Entity supports non-editable settings, but no default non-editable key was found. |
| Sensitive keys | No sensitive default keys found. Existing payment secrets remain in application properties, not SYS-01 settings. |
| Validation | Yes, by type in `validateAndNormalize()`: boolean true/false, integer parse, decimal parse, email regex/length, string non-blank/max length. |
| Cache | No `@Cacheable`, cache manager, or local settings cache found for SYS-01. Reads hit repository after `ensureDefaults()`. |
| Audit | Partial. `updated_by`, `created_at`, `updated_at`, and an info log on value change exist. No immutable history/audit table for settings changes. |
| Effect timing | Since there is no cache, values are readable immediately from DB by SYS-01 APIs. However, most business logic does not appear to consume these settings, so changing keys may not affect runtime behavior unless a caller explicitly reads them. No restart mechanism was found. |

### Current DB Values

| Key | Value | Type | Editable |
|---|---|---|---|
| `commerce.currency` | `VND` | `STRING` | true |
| `commerce.teacherCommissionRate` | `0.70` | `DECIMAL` | true |
| `learning.defaultEnrollmentStatus` | `ACTIVE` | `STRING` | true |
| `site.maintenanceMode` | `false` | `BOOLEAN` | true |
| `site.name` | `LumiNa E-Learning` | `STRING` | true |
| `site.supportEmail` | `support@lumina.edu.vn` | `EMAIL` | true |

## Required Root Cause Table

| Feature | Triệu chứng | Nguyên nhân gốc | File/Method/Query | Phương án sửa tối thiểu | Rủi ro |
|---|---|---|---|---|---|
| ANL-01 | Teacher revenue is shown as item-level gross revenue and recognized on order creation date, not actual payment completion date. | Analytics source is `OrderItem.unitPrice` + `Order.status = PAID` + `Order.createdAt`; `Order` has no `paidAt/completedAt/updatedAt`. | `TeacherRevenueAnalyticsServiceImpl.getRevenueAnalytics()`; `OrderItemRepository.sumTeacherRevenue()`; `findTeacherRevenueEvents()`; `Order.createdAt`. | Add/derive a paid timestamp, preferably when webhook marks the order paid, then filter/group revenue by that timestamp. Keep `OrderItem` item-level sum for teacher allocation. | Backfilling historical paid timestamps is ambiguous; changing time basis will change existing reports. |
| ANL-01 | Teacher commission/net revenue cannot be reported even though `commerce.teacherCommissionRate` exists. | Analytics never reads SYS-01 setting and does not apply platform fee/commission; revenue is gross `unitPrice`. | `TeacherRevenueAnalyticsServiceImpl`; `SystemSettingServiceImpl.defaultSettings()` defines `commerce.teacherCommissionRate`. | Decide whether ANL-01 should show gross, net, or both. If net is required, read commission setting and expose separate DTO fields. | Changing current total to net could break expectations; use separate fields to avoid silent semantic change. |
| ANL-01 | Potential future multi-item order requires careful teacher allocation. | Schema allows many `OrderItem` per `Order` and each item can belong to a different teacher; current create flow creates one item only. Queries sum by item and count orders distinctly. | `Order.items`; `OrderItem.course`; `OrderServiceImpl.createOrder()`; `OrderItemRepository.countTeacherPaidOrders()` uses `count(distinct o.id)`. | Keep item-level revenue allocation. If cart/multi-course checkout is added, add tests for multi-teacher orders and define whether order count is per platform order or per teacher sale. | If product changes to carts without tests, teacher order counts and platform totals can be misinterpreted. |
| ANL-02 | Dashboard total revenue/paid orders are all-time, while new/active students are date-range based. | `getDashboardOverview()` applies date range only to new/active students; `paidOrderCount` and `totalRevenue` call all-time queries. | `AdminAnalyticsServiceImpl.getDashboardOverview()`; `orderRepository.countByStatus(OrderStatus.PAID)`; `orderItemRepository.sumPaidRevenue(OrderStatus.PAID)`. | Decide dashboard semantics. If selected period should apply to revenue/orders, use period-scoped queries already present for ANL-04. | Changing dashboard numbers may surprise users because historical all-time totals become period totals. |
| ANL-02/ANL-04 | Revenue excludes refunded orders only after order status is changed to `REFUNDED`; refund amounts are not subtracted independently. | Analytics filters `Order.status = PAID`; refund table is not joined. Successful refund flow changes order status, but partial refund is not modeled. | `PaymentServiceImpl.refundOrder()`; `OrderItemRepository.sumPaidRevenue*()`; `RefundTransaction`. | If only full refunds exist, document this rule. If partial refunds are needed, add refund amount accounting and net revenue fields. | Introducing refund subtraction can alter historical totals and requires clear gross/net definitions. |
| ANL-03 | "New student" means account creation date, not role-assignment date or first enrollment. | No role history/role-assigned timestamp exists; query uses `User.createdAt` where `role = STUDENT`. | `UserRepository.findNewStudentEvents()`; `AdminAnalyticsServiceImpl.getStudentAnalytics()`; `User.createdAt`. | Document current definition in UI/report text. If business wants first enrollment or role assignment, add explicit timestamp/source and migrate/backfill. | Redefining without migration will produce inconsistent historical numbers. |
| ANL-03 | Active students can miss activity from quiz/submission-only workflows and can include progress row updates as activity. | Active source is only `LessonProgress.coalesce(lastAccessedAt,lastUpdatedAt)`; submissions, quiz attempts, enrollments, and login are not included. | `LessonProgressRepository.countActiveStudentsForAnalytics()`; `findActiveStudentEventsForAnalytics()`; `AdminAnalyticsServiceImpl.ACTIVE_STUDENT_METHOD`. | Either keep and document "lesson-progress active", or add a unified activity event source that records lesson open, quiz submit, assignment submit, and login if desired. | Combining sources can double count unless deduped by student/time bucket. A new event model needs careful migration. |
| ANL-04 | Revenue by day/month/year is grouped by order creation date, not paid date. | Same revenue root as ANL-01: event projection exposes `o.createdAt as createdAt`. | `OrderItemRepository.findPaidRevenueEvents()`; `AdminAnalyticsServiceImpl.buildRevenueTrend()`. | Use paid timestamp once available; keep `createdAt` only for order-created analytics. | Historical chart buckets will shift after fix; requires communication and tests. |
| SYS-01 | Settings UI edits may not change actual business behavior. | Settings are persisted, but most business logic uses hard-coded/default property paths and does not read `SystemSettingService`. Example: analytics ignores `commerce.currency` and `commerce.teacherCommissionRate`. | `SystemSettingServiceImpl`; `AdminSettingsRestController`; absence of callers in business services. | Wire specific settings to consumers one by one, starting with low-risk display settings; document unsupported keys until consumed. | Making settings effective globally can alter commerce/payment/learning behavior unexpectedly. |
| SYS-01 | No immutable audit trail for setting changes. | Entity stores only current `updated_by` and timestamps; service logs old/new value but does not persist history. | `SystemSetting.updatedBy`; `SystemSettingServiceImpl.updateSettingValue()`. | Add `SystemSettingAudit` table for key, old value, new value, admin, timestamp. | Auditing sensitive values later requires masking rules; current defaults are not sensitive. |
| SYS-01 | All default settings are editable; no sensitive-key protection beyond absence of sensitive defaults. | `ensureDefaults()` inserts every default with `editable(true)`. Type validation exists, but key-level sensitivity/editability policy is not modeled for defaults. | `SystemSettingServiceImpl.ensureDefaults()` and `defaultSettings()`. | Mark operational/sensitive keys non-editable or add key metadata if future sensitive settings are introduced. | Over-restricting could make intended admin settings unusable; under-restricting could expose unsafe controls later. |

## Minimal Fix Themes, Not Applied

No fixes were applied in this phase. The lowest-risk future fixes appear to be:

1. Document current definitions in UI/report labels: revenue is gross item revenue by `Order.createdAt`; new student is `User.createdAt`; active student is lesson progress activity.
2. Add a paid timestamp before changing revenue grouping semantics.
3. Add focused tests for multi-item/multi-teacher order analytics before enabling cart-like orders.
4. Decide whether SYS-01 settings are only administrative metadata or runtime configuration, then wire individual keys to consumers deliberately.

## Stop Point

Report created only. Code remains unchanged.

# 10 - UI/UX Review for ANL-01..04 and SYS-01

Date: 2026-07-14

Scope:
- ANL-01: Teacher revenue analytics
- ANL-02: Admin dashboard
- ANL-03: Admin student analytics
- ANL-04: Admin revenue report
- SYS-01: Admin system settings

## Lỗi UI tìm thấy

1. Active navigation chưa đúng cho route alias/report:
   - `/admin/analytics/revenue` và `/admin/reports/revenue` không match sidebar link `/admin/analytics`.
   - `/admin/statistics/students` không match sidebar link `/admin/analytics`.
   - `/admin/system-settings` không match sidebar link `/admin/settings`.
   - `/instructor/analytics` không match sidebar link `/teacher/analytics`.

2. Admin dashboard page title/topbar chưa nhất quán:
   - Topbar dùng `Command Center`, trong khi route và navigation là Dashboard.

3. KPI card thiếu metadata rõ ở một số khu vực:
   - Teacher analytics thiếu period/unit trực tiếp trong từng KPI card.
   - Một số Admin analytics/revenue KPI thiếu unit/period/method text rõ trên card.

4. Chart thiếu mô tả trực quan phù hợp:
   - Chart đã có title nhưng thiếu legend/axis text hiển thị.
   - Bar chỉ dùng `title`; bổ sung focus/ARIA để tooltip native có thể dùng bằng keyboard.

5. Table empty state chưa đủ rõ:
   - Admin student/revenue table render body rỗng khi trend không có rows.

6. Filter/form có thể submit nhiều lần:
   - Admin analytics/revenue/dashboard và Teacher analytics chưa disable controls trong lúc request đang chạy.

7. Number/currency formatting có rủi ro render `NaN`:
   - `Number(value || 0)` không chặn được non-numeric string. Đã đổi sang guard `Number.isFinite`.

8. Teacher JS có console log không cần thiết:
   - `console.log('Teacher JS loaded')` gây noise cho console checklist.

9. Responsive/table/chart:
   - Table cần min-width trong vùng scroll để tránh nén cell quá mức trên mobile.
   - Card header có action button cần wrap/stack trên mobile.

## File sửa

- `src/main/resources/templates/admin/dashboard.html`
- `src/main/resources/templates/admin/analytics.html`
- `src/main/resources/templates/admin/revenue-report.html`
- `src/main/resources/templates/teacher/analytics.html`
- `src/main/resources/static/css/admin/admin.css`
- `src/main/resources/static/css/teacher/teacher.css`
- `src/main/resources/static/js/admin/admin.js`
- `src/main/resources/static/js/admin/analytics.js`
- `src/main/resources/static/js/teacher/teacher.js`
- `src/main/resources/static/js/teacher/analytics.js`

## Breakpoint đã kiểm tra

Live browser screenshot/console check: chưa chạy được vì browser backend trong môi trường Codex không khả dụng (`agent.browsers.list()` trả về `[]`).

Đã kiểm tra tĩnh theo breakpoint bắt buộc:

| Breakpoint | Kết quả kiểm tra tĩnh |
| --- | --- |
| 1440px | Sidebar/topbar dùng portal grid 220px + content; analytics grids giữ nhiều cột; chart/table nằm trong vùng content. |
| 1024px | Admin overview/dashboard panels về 2 cột qua `max-width: 1100px`; base `.grid-main-aside` về 1 cột qua `max-width: 1024px`. |
| 768px | Portal sidebar ẩn theo design system; content grid về 1 cột/2 cột tùy stats; filter header bắt đầu stack quanh ngưỡng 760px. |
| 390px | Filter controls/buttons width 100%; chart/table có horizontal scroll trong chart/table container; card headers stack và action button full-width. |

## Verification

- `node --check src/main/resources/static/js/admin/analytics.js`: pass
- `node --check src/main/resources/static/js/admin/admin.js`: pass
- `node --check src/main/resources/static/js/admin/settings.js`: pass
- `node --check src/main/resources/static/js/teacher/analytics.js`: pass
- `node --check src/main/resources/static/js/teacher/teacher.js`: pass
- `.\mvnw.cmd "-Dtest=AdminAnalyticsControllerTest,TeacherAnalyticsControllerTest,AdminSettingsControllerTest" test`: pass
  - Tests run: 52
  - Failures: 0
  - Errors: 0

## Lỗi còn lại

- Chưa xác nhận được bằng browser live tại 1440/1024/768/390 do môi trường không có browser backend khả dụng.
- Chưa xác nhận được JavaScript console runtime trên trình duyệt thật; đã kiểm tra syntax JS và không còn `console.*` trong JS thuộc phạm vi.
- `admin.css` và `teacher.css` vẫn có một số selector role-level/global có sẵn như `.lumina-portal-main`; không đổi để tránh redesign hoặc ảnh hưởng ngoài phạm vi. Các selector mới được thêm đều scoped theo `admin-*`, `teacher-*`, `analytics-*`.
- `admin-chart-ph` vẫn tồn tại trong CSS cho trang Admin Payments ngoài phạm vi; các trang ANL-01..04/SYS-01 không dùng placeholder chart đó.

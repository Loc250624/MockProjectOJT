# SYS-01 Result - Admin System Settings

## Scope

- Chi sua SYS-01 va dependency truc tiep.
- Khong dua toan bo `application.properties` len giao dien.
- Khong expose payment token, password, API key, secret plaintext ra browser hoac log.

## Inventory setting

| Key | Category | Type | Default | Editable | Sensitive | Storage |
| --- | --- | --- | --- | --- | --- | --- |
| `site.name` | Site | STRING | `LumiNa E-Learning` | Yes | No | DB `SystemSettings.setting_value` |
| `site.maintenanceMode` | Site | BOOLEAN | `false` | Yes | No | DB `SystemSettings.setting_value` |
| `site.supportEmail` | Site | EMAIL | `support@lumina.edu.vn` | Yes | No | DB `SystemSettings.setting_value` |
| `commerce.currency` | Commerce | ENUM | `VND` | Yes | No | DB `SystemSettings.setting_value` |
| `commerce.teacherCommissionRate` | Commerce | DECIMAL | `0.70` | Yes | No | DB `SystemSettings.setting_value` |
| `learning.defaultEnrollmentStatus` | Learning | ENUM | `ACTIVE` | Yes | No | DB `SystemSettings.setting_value` |

## Supported settings

- `site.name`: string, required, length 3-120.
- `site.maintenanceMode`: boolean, required.
- `site.supportEmail`: email, required, max 320.
- `commerce.currency`: enum, required, allowed `VND`, `USD`.
- `commerce.teacherCommissionRate`: decimal, required, min `0`, max `1`.
- `learning.defaultEnrollmentStatus`: enum, required, allowed `ACTIVE`, `INACTIVE`.

## Intentionally not editable

- Datasource settings.
- Payment gateway endpoint/secret/token/key settings.
- JWT, OAuth, mail, server, logging, and framework settings from `application.properties`.
- Any DB row whose key is not in the SYS-01 whitelist.

## Backend result

- `GET /api/admin/settings` returns only whitelisted DB settings.
- `PUT /api/admin/settings/{key}` and `POST /api/admin/settings/bulk` update only whitelisted keys.
- Unknown keys are rejected before save.
- Bulk update validates all keys and values before persisting, avoiding partial mass assignment.
- Missing whitelisted keys are recreated from safe defaults.
- Validation supports STRING, INTEGER, DECIMAL, BOOLEAN, EMAIL, URL, and ENUM. The current whitelist has no URL key.
- Min/max validation is enforced where configured.
- `updatedAt` is maintained by Hibernate `@UpdateTimestamp`; `updatedBy` is set to the admin user on real value changes.
- No cache layer was found; changed settings are readable immediately by code paths that read `SystemSettingService`.
- Logs record key/admin/sensitive flag only, not old/new values.
- Legacy `PATCH /api/admin/system-settings` no longer returns a fake successful update; it returns 410 with guidance to use the whitelisted API.
- Project-wide Spring CSRF remains in the pre-existing disabled state; SYS-01 state-changing endpoints now require `X-Requested-With: XMLHttpRequest` and this guard is covered by tests.

## Frontend result

- Uses existing Admin layout and sidebar.
- Groups settings by category.
- Shows label, help text, type metadata, and validation beside fields.
- Boolean uses checkbox.
- ENUM uses select.
- Number uses number input.
- Sensitive handling is supported with password input and blank value semantics, but no sensitive key is currently whitelisted.
- Save button has disabled/loading state.
- Success/error states are shown.
- Layout remains responsive through the existing admin settings grid and mobile breakpoint.

## Files changed

- `src/main/java/com/ojtsu26/elearning/model/enums/SystemSettingType.java`
- `src/main/java/com/ojtsu26/elearning/dto/response/SystemSettingResponseDTO.java`
- `src/main/java/com/ojtsu26/elearning/service/impl/SystemSettingServiceImpl.java`
- `src/main/java/com/ojtsu26/elearning/controller/api/AdminSettingsRestController.java`
- `src/main/java/com/ojtsu26/elearning/controller/AdminActionController.java`
- `src/main/resources/static/js/admin/settings.js`
- `src/main/resources/static/css/admin/admin.css`
- `src/test/java/com/ojtsu26/elearning/controller/AdminSettingsControllerTest.java`
- `reports/09-sys-01-result.md`

## Tests

Covered:

- Load settings.
- Missing key fallback.
- Invalid value/type.
- Valid single update.
- Valid bulk update.
- Update key outside whitelist.
- Anonymous access blocked.
- Student access blocked.
- Teacher access blocked.
- Admin update without request verification header blocked.
- Sensitive/non-whitelisted secret setting not exposed.
- Legacy placeholder endpoint does not report success.
- Cache/effective behavior: no cache found; immediate read-back behavior documented and covered by service/API read after save.

## Verification

- `node --check src\main\resources\static\js\admin\settings.js`: passed.
- `.\mvnw.cmd clean test-compile`: passed.
- `.\mvnw.cmd -q -Dtest=AdminSettingsControllerTest test`: passed, 15 tests, 0 failures, 0 errors.
- `.\mvnw.cmd -q -DskipTests compile`: passed.

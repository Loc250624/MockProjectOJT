# 12 - Full Regression Report

Date: 2026-07-14

Scope: full project regression after ANL-01, ANL-02, ANL-03, ANL-04, and SYS-01.

## Commands run

| Command | Result |
| --- | --- |
| `git status` | PASS, reviewed modified/untracked scope. |
| `git diff --stat` | PASS, reviewed changed file list and size. |
| `git diff` | PASS, reviewed diff output; tool output was truncated because diff is large. |
| `git diff --numstat` | PASS, no binary numstat rows. |
| `rg` secret/debug/temporary patterns in `src` and `reports` | REVIEWED. No new production secret/debugger/console.log found in ANL/SYS diff. Dummy secret strings exist in tests for leak-prevention coverage. Pre-existing secret findings remain documented in earlier reports. |
| `rg "console\.|debugger" src/main/resources/static/js/admin src/main/resources/static/js/teacher` | PASS, no matches. |
| `node --check src\main\resources\static\js\admin\admin.js` | PASS. |
| `node --check src\main\resources\static\js\admin\analytics.js` | PASS. |
| `node --check src\main\resources\static\js\admin\settings.js` | PASS. |
| `node --check src\main\resources\static\js\teacher\analytics.js` | PASS. |
| `node --check src\main\resources\static\js\teacher\teacher.js` | PASS. |
| `.\mvnw.cmd clean test` | PASS, `BUILD SUCCESS`. |
| Surefire XML aggregation | PASS, totals confirmed from `target/surefire-reports/TEST-*.xml`. |
| `rg` log scan for lazy/query/500 patterns in surefire reports | PASS, no `LazyInitializationException`, `SQLGrammarException`, `QueryException`, or unexpected 500 pattern found. |
| `.\mvnw.cmd spring-boot:run` | STARTED successfully on `localhost:8080`; live smoke was performed. Shutdown used `Stop-Process`, so Maven ended with expected process termination exit `-1`. |
| Live HTTP smoke with `Invoke-WebRequest -UseBasicParsing` | PASS for checked routes/APIs listed below. |

`.\mvnw.cmd verify` was not run because `clean test` passed and no verify-only failure signal was found.

## Test totals

| Metric | Count |
| --- | ---: |
| Total tests | 276 |
| Pass | 276 |
| Failures | 0 |
| Errors | 0 |
| Skipped | 0 |

## Git diff hygiene

| Check | Result |
| --- | --- |
| Binary files | PASS, no binary rows in `git diff --numstat`. |
| `target/` in git diff/status | PASS, not present in git status/diff. `target/` exists locally after Maven build only. |
| Out-of-scope files | PASS, modified source/test/static/template files map to ANL/SYS and related regression reports. |
| Secrets | PASS for new production diff. Test-only dummy values are intentional. Pre-existing application secret concerns are not new to this regression. |
| Debug code | PASS, no `debugger`, `System.out.println`, `printStackTrace`, or changed-scope `console.log`. |
| Temporary hard-code/mock data | PASS for changed ANL/SYS production scope. |
| JS console noise | PASS in admin/teacher changed JS scope. |

## Business regression

| Area | Result | Evidence |
| --- | --- | --- |
| Login/logout | PASS | Live login worked for local admin/teacher/student accounts; `/auth/logout` returned `302`. Automated auth tests also passed. |
| OAuth route | PASS, partial | `/oauth2/authorization/google` returned `302`. External provider round trip was not performed. |
| Student dashboard | PASS | Live `/student/dashboard` returned `200`. |
| Student my courses | PASS | Live `/student/my-courses` returned `200`. |
| Course detail | PASS | Live `/student/courses/detail?id=20` returned `200`. |
| Enrollment/payment entry | PASS | Live `/student/checkout?courseId=1` returned `200`; `OrderServiceTest` and `PaymentServiceTest` passed. |
| Lesson progress | PASS | Live `/student/learning?courseId=20&lessonId=65` returned `200` and updated lesson progress without server error. |
| Quiz/assignment basic | PASS, partial live | Generic student quiz and code-assignment pages returned `200`; automated assessment tests passed. Local enrolled course did not provide a live quiz/assignment end-to-end path. |
| Teacher dashboard | PASS | Live `/teacher/dashboard` returned `200`. |
| Teacher course management | PASS | Live `/teacher/courses` returned `200`; teacher course/student tests passed. |
| Admin user management | PASS | Live `/admin/users` and `/api/admin/users` returned `200`; admin user tests passed. |
| Admin course management | PASS | Live `/admin/courses` returned `200`; course enrollment and admin route tests passed. |
| Blog management | PASS | Live `/admin/blogs` returned `200`; blog post/comment tests passed. |
| Payment/order flow | PASS | Live checkout/payment history returned `200`; order/payment provider tests passed. |
| Navigation by role | PASS | Live role-specific routes returned `200`; RBAC tests passed for admin/teacher/student access rules. |

## ANL/SYS regression matrix

| Feature | Result | Evidence |
| --- | --- | --- |
| ANL-01 | PASS | `TeacherAnalyticsControllerTest` 15/15, `TeacherRevenueAnalyticsServiceTest` 5/5, live teacher analytics page/API `200`. |
| ANL-02 | PASS | `AdminAnalyticsControllerTest` covers dashboard overview; live dashboard page/API `200`. |
| ANL-03 | PASS | `AdminAnalyticsControllerTest` covers student analytics; live student analytics page/API `200`. |
| ANL-04 | PASS | `AdminAnalyticsControllerTest` covers revenue analytics; live revenue page/API `200`. |
| SYS-01 | PASS | `AdminSettingsControllerTest` 23/23, live settings page/API `200`, JS syntax pass, request header guard covered by tests. |

## Log review

| Check | Result |
| --- | --- |
| Server exception | PASS, no unexpected server exception found during successful test/live smoke. Expected negative-test exceptions appeared in surefire logs. |
| Query error | PASS, no SQL grammar/query exception found. |
| Lazy initialization error | PASS, none found. |
| JavaScript console error | PARTIAL, no browser console capture was available; static JS syntax passed and no admin/teacher `console.*` remained. |
| Unexpected 404/500 | PASS for checked routes; live smoke statuses were `200` or expected `302`. |
| Severe new security warning | PASS, none found. Existing warnings include Hibernate dialect/config warnings and one pagination warning on payment history. |

Expected/known log lines:
- Initial failed login for absent baseline seed account `admin0@elearning.com` returned `401`; local DB uses different accounts.
- Negative tests intentionally log access denied, bad/malformed request, gateway config/signature/refund failure, and blocked/deleted login cases.
- Live payment history emitted Hibernate warning `HHH90003004: firstResult/maxResults specified with collection fetch; applying in memory`; no request failure occurred.

## Regression detected

No blocking regression was detected by automated tests or live HTTP smoke.

Non-blocking observations:
- Local DB did not contain baseline seed accounts `admin0@elearning.com`, `teacher0@elearning.com`, `student0@elearning.com`; live smoke used existing local accounts `locnqhe181507@fpt.edu.vn`, `cuong123@gmail.com`, and `loc25624@gmail.com`.
- Browser console/runtime visual checks were not captured in this run.
- Full external OAuth provider callback and real payment gateway round trip were not performed.

## Regression fixed

No code fix was made during this regression pass.

## Not fully checked

- Browser console errors, responsive visual overlap, and actual rendered chart pixels in a real browser session.
- External OAuth provider login callback.
- External payment provider completion beyond local checkout/payment/order tests.
- Live end-to-end quiz/assignment submission for the local student account, because the enrolled course used for smoke only had video lessons.

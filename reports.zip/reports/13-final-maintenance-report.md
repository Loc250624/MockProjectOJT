# 13 - Final Maintenance Report

Date: 2026-07-14

## 1. Tong quan

| Hang muc | Gia tri |
|---|---|
| Branch | `feature/anl-and-sys-maintainance` |
| Commit bat dau | `f8cb855` - `Apply BCrypt migration: use standard BCryptPasswordEncoder with PasswordMigrationRunner` |
| HEAD hien tai khi lap bao cao | `8b7b63c` - `Fix admin status` |
| Pham vi | ANL-01 Teacher revenue analytics; ANL-02 Admin dashboard; ANL-03 Admin student analytics; ANL-04 Admin revenue analytics; SYS-01 Admin system settings; UI/UX; Security/RBAC; regression |
| Khong thuc hien | Khong `git add`, khong `git commit`, khong `git push`; khong sua du lieu production; khong doi schema/migration |

| Feature | Trang thai | Ghi chu |
|---|---|---|
| ANL-01 | PASS | Teacher revenue dung authenticated teacher, validate owned `courseId`, chi tinh `PAID`, them paid students/currency, test IDOR va multi-item/multi-teacher. |
| ANL-02 | PASS | Dashboard dung real repository data, KPI/chart co loading/empty/error state, route/RBAC duoc test. |
| ANL-03 | PASS | New/active student metric duoc dinh nghia ro, active student loc dung role `STUDENT`, them timezone metadata. |
| ANL-04 | PASS | Revenue trend group day/month/year bang DB bucket aggregation, KPI/chart/table nhat quan, validate date/groupBy. |
| SYS-01 | PASS | Settings chi expose whitelist DB settings, validate type/range/enum, khong expose secret, legacy placeholder tra 410. |
| UI/UX | PASS/PARTIAL | Static JS/CSS va controller tests pass; live browser screenshot/console khong day du do browser backend khong kha dung trong mot so buoc. |
| Security/RBAC | PASS/PARTIAL | MockMvc/RBAC/IDOR/input tests pass; browser network secret capture va session timeout theo clock thuc chua test. |
| Full regression | PASS | `clean test` pass 276/276; live HTTP smoke pass cho cac route chinh. |

## 2. Root cause

| Feature | Loi ban dau | Nguyen nhan goc | Muc do |
|---|---|---|---|
| ANL-01 | KPI thieu paid students/currency; frontend hard-code currency; test chua khoa du case pending/failed/refunded/multi-teacher. | API response thieu field; JS format tien bang hang so; coverage chua bao quanh het policy revenue/ownership. | Medium |
| ANL-01 | Revenue khong co paid timestamp/net commission. | Database/order model khong co `paidAt`/`completedAt`; analytics hien tai dung gross `OrderItem.unitPrice` va khong doc commission setting. | Medium |
| ANL-02 | Dashboard can ro hon ve KPI source, state va navigation. | UI co widget that nhung metadata/loading/error state chua day du; mot so KPI la all-time trong khi chart theo period. | Medium |
| ANL-03 | Active student metric co the dem sai role va de gay hieu nham. | Query lesson progress chua rang buoc role `STUDENT`; he thong khong co login/activity event log tong hop. | Medium |
| ANL-04 | Revenue trend can consistency giua KPI/chart/table va grouping day/month/year. | Logic cu dua tren event projection va group trong service; can DB bucket aggregation de tranh lech tong va duplicate order count. | Medium |
| SYS-01 | Settings co nguy co expose/cap nhat qua rong; legacy endpoint tra ket qua fake success. | Service dua vao DB settings chung, chua co whitelist/metadata policy chat; Spring CSRF dang disable global; placeholder API con ton tai. | High |
| UI | Alias/report routes khong highlight menu active; mot so KPI/chart/table state chua ro; console noise. | Active menu match exact pathname; JS/CSS chua xu ly tat ca alias, loading/empty/error va guard number format. | Low |
| Security | Malformed date co the tra 500; setting string chap nhan markup. | Chua co handler `MethodArgumentTypeMismatchException`; validation STRING chua chan `<`/`>`. | Medium |

## 3. Thay doi

| File | Noi dung sua | Feature | Ly do |
|---|---|---|---|
| `src/main/java/com/ojtsu26/elearning/repository/OrderItemRepository.java` | Them count paid students cho teacher; thay admin revenue events bang bucket queries day/month/year. | ANL-01, ANL-04 | Dem distinct student/order va tong hop revenue nhat quan tu DB. |
| `src/main/java/com/ojtsu26/elearning/repository/projection/AdminRevenueBucketProjection.java` | Them projection bucket revenue. | ANL-04 | Ho tro aggregate theo ngay/thang/nam. |
| `src/main/java/com/ojtsu26/elearning/repository/projection/AdminRevenueEventProjection.java` | Xoa projection event cu. | ANL-04 | Khong con dung sau khi chuyen sang bucket aggregation. |
| `src/main/java/com/ojtsu26/elearning/service/impl/TeacherRevenueAnalyticsServiceImpl.java` | Tra `paidStudentCount` va `currency`; giu ownership/status/date policy. | ANL-01 | Bo sung KPI va giam hard-code frontend. |
| `src/main/java/com/ojtsu26/elearning/dto/response/TeacherRevenueAnalyticsResponseDTO.java` | Them `currency`, `paidStudentCount`. | ANL-01 | Mo rong response an toan cho UI. |
| `src/main/java/com/ojtsu26/elearning/service/impl/AdminAnalyticsServiceImpl.java` | Loc active student theo role; them timezone/method; dung bucket revenue; validate group/date. | ANL-02, ANL-03, ANL-04 | Chot dinh nghia metric va dam bao KPI/chart/table consistency. |
| `src/main/java/com/ojtsu26/elearning/repository/LessonProgressRepository.java` | Active student query nhan `Role.STUDENT`. | ANL-03 | Khong dem non-student activity. |
| `src/main/java/com/ojtsu26/elearning/dto/response/AdminStudentAnalyticsDTO.java` | Them `timeZone`. | ANL-03 | UI hien thi ngu canh ngay/gio. |
| `src/main/java/com/ojtsu26/elearning/dto/response/AdminRevenueAnalyticsDTO.java` | Them `timeZone`, `revenueRecognitionMethod`. | ANL-04 | Document revenue basis trong API. |
| `src/main/java/com/ojtsu26/elearning/model/enums/SystemSettingType.java` | Bo sung/ho tro type moi nhu `URL`, `ENUM`. | SYS-01 | Validation theo metadata whitelist. |
| `src/main/java/com/ojtsu26/elearning/dto/response/SystemSettingResponseDTO.java` | Them label/unit/storage/effective/sensitive/required/range/options metadata. | SYS-01 | UI render va validate ro rang, khong expose secret value. |
| `src/main/java/com/ojtsu26/elearning/service/impl/SystemSettingServiceImpl.java` | Them whitelist definitions, validation all-before-save, secret masking, metadata sync, safe logging. | SYS-01, Security | Chan mass assignment, secret exposure, invalid value va partial bulk update. |
| `src/main/java/com/ojtsu26/elearning/controller/api/AdminSettingsRestController.java` | Yeu cau request verification header cho write endpoints. | SYS-01, Security | Giam rui ro khi Spring CSRF token dang disable. |
| `src/main/java/com/ojtsu26/elearning/controller/AdminActionController.java` | Legacy `PATCH /api/admin/system-settings` tra 410. | SYS-01 | Khong con fake success placeholder. |
| `src/main/java/com/ojtsu26/elearning/exception/GlobalExceptionHandler.java` | Map malformed request/type mismatch ve 400. | Security | Date sai format khong con thanh 500. |
| `src/main/resources/templates/admin/dashboard.html` | Cap nhat KPI metadata/link/state. | ANL-02, UI | Dashboard ro source va dieu huong hon. |
| `src/main/resources/templates/admin/analytics.html` | Them metric definition/timezone/empty state context. | ANL-03, UI | Giam nham lan new/active student. |
| `src/main/resources/templates/admin/revenue-report.html` | Them revenue basis, KPI/table/chart context. | ANL-04, UI | Hien thi policy revenue cho admin. |
| `src/main/resources/templates/admin/settings.html` | Render setting metadata va validation UI. | SYS-01, UI | Chi sua whitelist setting an toan. |
| `src/main/resources/templates/teacher/analytics.html` | Them paid students KPI va subtitle ro hon. | ANL-01, UI | Hoan thien dashboard teacher. |
| `src/main/resources/static/js/admin/admin.js` | Sua active navigation cho alias/report routes. | UI | Menu dung tren `/admin/statistics/students`, `/admin/analytics/revenue`, `/admin/system-settings`. |
| `src/main/resources/static/js/admin/analytics.js` | Loading/empty/error state, safe number format, settled requests, revenue/student rendering. | ANL-02, ANL-03, ANL-04, UI | Tranh NaN/blank UI va mot API fail lam sap ca page. |
| `src/main/resources/static/js/admin/settings.js` | Render whitelist metadata, bulk save guarded header, disabled/loading/success/error states. | SYS-01, UI, Security | Cap nhat settings an toan va de kiem tra. |
| `src/main/resources/static/js/teacher/analytics.js` | Dung currency tu API, render paid students, safe format/state. | ANL-01, UI | Bo hard-code va console noise. |
| `src/main/resources/static/js/teacher/teacher.js` | Loai console noise/minor UI support. | UI | Giu console sach. |
| `src/main/resources/static/css/admin/admin.css` | Bo sung responsive/state/chart/table/settings styles. | ANL-02..04, SYS-01, UI | Giu layout desktop/tablet/mobile on dinh. |
| `src/main/resources/static/css/teacher/teacher.css` | KPI grid 6 cards va responsive tweaks. | ANL-01, UI | Hien thi KPI moi khong vo layout. |
| `src/test/java/com/ojtsu26/elearning/controller/AdminAnalyticsControllerTest.java` | Mo rong test dashboard/student/revenue/RBAC/validation/consistency. | ANL-02, ANL-03, ANL-04, Security | Khoa behavior quan trong. |
| `src/test/java/com/ojtsu26/elearning/controller/AdminSettingsControllerTest.java` | Test whitelist, bulk/single update, header guard, secret non-exposure, legacy 410. | SYS-01, Security | Khoa write policy va RBAC. |
| `src/test/java/com/ojtsu26/elearning/controller/TeacherAnalyticsControllerTest.java` | Test anonymous/student/IDOR/date/multi-item/multi-teacher/refund policy. | ANL-01, Security | Khoa ownership va revenue policy. |
| `src/test/java/com/ojtsu26/elearning/service/TeacherRevenueAnalyticsServiceTest.java` | Cap nhat expected DTO va ownership/query consistency. | ANL-01 | Dam bao service khong lech API. |

## 4. Dinh nghia du lieu cuoi cung

| Hang muc | Dinh nghia cuoi cung |
|---|---|
| Revenue source | Gross revenue tu `OrderItem.unitPrice`, join `OrderItem -> Order`; teacher revenue join them `OrderItem -> Course -> instructor`. Khong tinh tax/discount/platform fee/net commission. |
| Success payment statuses | Analytics chi tinh `OrderStatus.PAID`. `TransactionStatus.SUCCESS` ton tai trong payment flow nhung khong la source truc tiep cho analytics. |
| Revenue timestamp | `Order.createdAt`. Hien chua co `Order.paidAt`/`completedAt`; chart/filter dung start inclusive va next-day exclusive. |
| Refund policy | Successful refund flow chuyen `Order.status` sang `REFUNDED`; analytics chi lay `PAID` nen refunded orders bi loai. Chua co partial refund/net refund accounting. |
| Teacher ownership rule | Teacher lay tu authenticated principal/`CurrentUserService`; API khong tin `teacherId` client. Optional `courseId` phai thuoc `Course.instructor.id` cua teacher hien tai, neu khong tra 403. |
| New student definition | Distinct `User.id` co `User.role = STUDENT` va `User.createdAt` nam trong selected range. Khong dung role assignment date/first enrollment date. |
| Active student definition | Distinct `User.id` role `STUDENT` co `LessonProgress` activity trong range, timestamp la `coalesce(lastAccessedAt, lastUpdatedAt)`. |
| System setting storage | DB `SystemSettings`/`system_settings`, field `setting_value`, qua entity `SystemSetting`; defaults duoc tao lai lazy neu thieu. |
| Sensitive setting policy | Chi expose/update key trong whitelist; payment/datasource/JWT/OAuth/mail/framework secrets khong editable qua SYS-01. Sensitive value neu co trong whitelist se duoc mask blank trong DTO; blank update giu gia tri cu; log khong ghi old/new value. |
| Timezone | Date filters/metadata dung application JVM zone qua `ZoneId.systemDefault()`. Maintenance run nay o `Asia/Bangkok`; app khong co timezone config rieng trong cac bao cao. |

## 5. Test

| Test/Command | Ket qua | Ghi chu |
|---|---|---|
| `.\mvnw.cmd clean compile` | PASS | Baseline compile, `BUILD SUCCESS`. |
| `.\mvnw.cmd test` | PASS | Baseline 225 tests, 0 fail/error/skip. |
| `node --check src\main\resources\static\js\teacher\analytics.js` | PASS | ANL-01 JS syntax. |
| `.\mvnw.cmd "-Dtest=TeacherRevenueAnalyticsServiceTest,TeacherAnalyticsControllerTest" test` | PASS | ANL-01, 17 tests. |
| `.\mvnw.cmd -q -Dtest=AdminAnalyticsControllerTest test` | PASS | ANL-02 11 tests; ANL-03 17 tests; ANL-04 25 tests tai cac moc rieng. |
| `node --check src\main\resources\static\js\admin\analytics.js` | PASS | Admin analytics/dashboard/revenue JS syntax. |
| `node --check src\main\resources\static\js\admin\settings.js` | PASS | SYS-01 JS syntax. |
| `.\mvnw.cmd -q -Dtest=AdminSettingsControllerTest test` | PASS | SYS-01, 15 tests. |
| `node --check src/main/resources/static/js/admin/admin.js` | PASS | UI navigation JS syntax. |
| `node --check src/main/resources/static/js/teacher/teacher.js` | PASS | Teacher shared JS syntax. |
| `.\mvnw.cmd "-Dtest=AdminAnalyticsControllerTest,TeacherAnalyticsControllerTest,AdminSettingsControllerTest" test` | PASS | UI pass 52 tests; security pass 67 tests tai report rieng. |
| `.\mvnw.cmd clean test` | PASS | Final regression 276 tests, 0 failures, 0 errors, 0 skipped. |
| `.\mvnw.cmd spring-boot:run` | PASS/PARTIAL | App start tren `localhost:8080`; stop bang `Stop-Process` nen Maven exit `-1` du kien. |
| Live HTTP smoke | PASS | Checked routes/APIs tra `200` hoac expected `302`; external OAuth/payment callback khong test. |
| Browser console/screenshot runtime | PARTIAL | Khong co browser session trong mot so buoc; regression khong capture console thuc. |

## 6. Security

| Hang muc | Ket qua | Ghi chu |
|---|---|---|
| RBAC | PASS | Anonymous redirect/401; Student/Teacher bi chan khoi admin; Student/Admin bi chan khoi teacher API theo route policy; Admin vao admin ANL/SYS. |
| IDOR | PASS | Teacher analytics lay teacher tu principal; `courseId` khac owner tra 403; `teacherId/userId/orderId` query param khong mo rong scope. |
| CSRF | PARTIAL | Spring Security CSRF token dang disable global tu truoc; SYS-01 write endpoints them `X-Requested-With: XMLHttpRequest` guard va test thieu header tra 403. |
| Secret exposure | PASS/PARTIAL | Static diff/template/JS/JSON tests khong expose secret moi; settings secret non-whitelist khong ra JSON; browser network capture va live server log secret capture chua test. |
| Input validation | PASS | Date sai format/groupBy sai/SQL-like string/HTML markup/setting key sai/value qua dai/number out of range deu bi chan bang 400/403 phu hop. |

## 7. UI

| Khu vuc | Ket qua | Ghi chu |
|---|---|---|
| Desktop | PASS/PARTIAL | Baseline browser 1440px khong overflow; sau sua da review static va test. |
| Tablet | PASS/PARTIAL | Baseline 1024px/768px ok; CSS grid/table/filter co breakpoint; chua co screenshot live sau tat ca thay doi. |
| Mobile | PASS/PARTIAL | Baseline 390px ok; CSS stack controls, table/chart scroll, card header wrap; chua co screenshot live sau tat ca thay doi. |
| Empty/loading/error state | PASS | Admin dashboard/analytics/revenue, teacher analytics, settings co state tu template/JS va tests/static review. |
| Browser console | PARTIAL | JS syntax pass va `console.*` trong admin/teacher changed JS khong con; runtime browser console capture chua co trong regression. |

## 8. Known limitations

| Hang muc | Gioi han |
|---|---|
| Khong the kiem tra | Browser console runtime, screenshot responsive sau tat ca thay doi, browser network secret capture, session timeout theo thoi gian thuc. |
| Thieu du lieu | Local smoke khong co day du quiz/assignment live end-to-end cho enrolled course; local DB khac baseline seed accounts o mot so lan smoke. |
| Phu thuoc dich vu ngoai | OAuth provider callback that, MoMo/VNPay real gateway round trip, external email/payment side effects chua test. |
| Can migration | Khong co migration duoc them. Neu muon `paidAt`, audit immutable cho settings, unified student activity event, partial refund accounting thi can schema/migration/backfill. |
| Can restart | Khong thay doi yeu cau restart rieng. SYS-01 khong co cache nen immediate cho code paths doc `SystemSettingService`; nhung nhieu business flow hien chua consume settings. Deployment production van can restart/redeploy ung dung nhu quy trinh binh thuong. |
| Data semantics | Revenue van la gross item revenue by `Order.createdAt`, khong phai paid timestamp/net revenue. Dashboard total revenue/paid orders la all-time theo policy hien tai. |
| Pre-existing secrets | `application.properties` da duoc report truoc do la co literal payment sandbox secrets; bao tri nay khong di chuyen chung ra secret store. |
| Line endings | `git diff --stat` canh bao LF se duoc thay bang CRLF khi Git cham file tren Windows. |

## 9. Huong dan manual verification

1. Chay `git status` va xac nhan chi co cac file ANL/SYS/report mong doi, khong co file out-of-scope can revert.
2. Chay `.\mvnw.cmd clean test` va xac nhan `BUILD SUCCESS`, 276 tests pass.
3. Chay `node --check` cho cac file:
   - `src\main\resources\static\js\admin\admin.js`
   - `src\main\resources\static\js\admin\analytics.js`
   - `src\main\resources\static\js\admin\settings.js`
   - `src\main\resources\static\js\teacher\analytics.js`
   - `src\main\resources\static\js\teacher\teacher.js`
4. Start app bang `.\mvnw.cmd spring-boot:run`.
5. Login admin, mo `/admin/dashboard`; doi filter date va xac nhan KPI/chart update, khong hien `NaN`, `undefined`, blank chart bat thuong.
6. Mo `/admin/analytics` va `/admin/statistics/students`; xac nhan active menu Analytics, KPI New/Active Students, viewed range/timezone, chart va table.
7. Mo `/admin/analytics/revenue` va `/admin/reports/revenue`; xac nhan active menu Analytics, revenue basis, group day/month/year, chart/table/KPI tong khop nhau.
8. Mo `/admin/settings` va `/admin/system-settings`; xac nhan active menu Settings, chi thay 6 whitelist settings, save valid value thanh cong.
9. Thu SYS-01 invalid values: unknown key, `site.name` qua ngan/qua dai/co `<script>`, commission < 0 hoac > 1, currency ngoai `VND/USD`; ky vong 400.
10. Dung DevTools Network de xac nhan SYS-01 write request co `X-Requested-With: XMLHttpRequest`; thu bo header neu co the va ky vong 403.
11. Login teacher, mo `/teacher/analytics`; xac nhan paid students/currency, date/course/group filters, chart, by-course table/cards.
12. Thu teacher A truyen `courseId` cua teacher B vao `/api/teacher/analytics/revenue`; ky vong 403.
13. Login student/teacher thu cac admin URL/API; ky vong page redirect `/` hoac API 403.
14. Anonymous thu protected page/API; ky vong page redirect `/auth/login` hoac API 401.
15. Kiem tra responsive bang browser DevTools tai 1440, 1024, 768, 390 px; xac nhan khong overlap/cut/off-screen, table/chart co scroll hop ly.
16. Mo browser console tren cac trang ANL/SYS; xac nhan khong co JavaScript error moi.
17. Kiem tra payment/OAuth thuc neu co sandbox credential hop le, vi regression hien chi smoke local va test provider mock/negative path.

## 10. Rollback

Khong rollback bang cach xoa du lieu DB. De quay lui code ma khong mat du lieu:

1. Tao patch/backup thay doi hien tai neu can giu lai review: `git diff > maintenance.patch`.
2. Neu cac thay doi chua commit, dung rollback theo file ANL/SYS cu the tu `git status`, vi du restore tung file source/template/static/test/report can bo. Khong dung `git reset --hard` neu worktree co thay doi cua nguoi khac.
3. Neu sau nay da commit maintenance, tao revert commit bang `git revert <maintenance-commit>` thay vi reset branch shared.
4. Giu nguyen DB `system_settings`; cac key whitelist la metadata an toan. Neu can quay ve gia tri setting cu, cap nhat lai qua UI/API hoac SQL backup, khong drop table.
5. Neu da deploy, redeploy artifact truoc maintenance hoac revert commit roi deploy lai. Restart app theo quy trinh deploy de nap code cu.
6. Neu da tao du lieu test local trong qua trinh manual verification, chi xoa du lieu test da biet ro nguon goc; khong chay truncate/drop tren database dung chung.

## Final git checks

`git status`:

| Hang muc | Ket qua |
|---|---|
| Branch | `feature/anl-and-sys-maintainance` |
| Changes not staged | 30 tracked source/test/static/template files modified/deleted |
| Untracked reports | `reports/01-code-inventory.md` through `reports/13-final-maintenance-report.md` |
| Untracked source | `src/main/java/com/ojtsu26/elearning/repository/projection/AdminRevenueBucketProjection.java` |
| Staged changes | None |

Tracked changes listed by `git status`:

- Modified: `AdminActionController.java`, `AdminSettingsRestController.java`, analytics/settings DTOs, `GlobalExceptionHandler.java`, `SystemSettingType.java`, `LessonProgressRepository.java`, `OrderItemRepository.java`, analytics/settings service impls, admin/teacher CSS/JS/templates, and related controller/service tests.
- Deleted: `src/main/java/com/ojtsu26/elearning/repository/projection/AdminRevenueEventProjection.java`.

`git diff --stat`:

```text
29 files changed, 2187 insertions(+), 228 deletions(-)
```

Ghi chu: `git diff --stat` chi tinh tracked diff, nen chua hien cac file untracked nhu reports `01..13` va `AdminRevenueBucketProjection.java`. Lenh nay cung in canh bao Windows line endings: `LF will be replaced by CRLF the next time Git touches it`.

## De xuat commit message

`fix: repair analytics dashboards and system settings`

# ANL-02 Result - Admin Overview Dashboard

Date: 2026-07-14

Scope: only ANL-02 and direct dashboard dependencies were changed.

## Inventory widget

Existing Admin Dashboard widgets found in `src/main/resources/templates/admin/dashboard.html`:

1. Total Users KPI card
2. Students KPI card
3. Teachers KPI card
4. Courses KPI card
5. Enrollments KPI card
6. Paid Orders KPI card
7. Total Revenue KPI card
8. New Students KPI card
9. Active Students KPI card
10. Student Growth chart
11. Revenue Trend chart

Not present on the current dashboard, so not added: new courses widget, new users widget, recent activity widget, dashboard table.

## KPI definitions and data sources

All KPI values are loaded through the aggregate dashboard DTO `AdminDashboardOverviewDTO` from `AdminAnalyticsServiceImpl.getDashboardOverview()`.

| Widget | Definition | Repository/source |
| --- | --- | --- |
| Total Users | Count of all user rows. | `UserRepository.count()` |
| Students | Count of users with role `STUDENT`. | `UserRepository.countByRole(Role.STUDENT)` |
| Teachers | Count of users with role `TEACHER`. | `UserRepository.countByRole(Role.TEACHER)` |
| Courses | Count of all course rows. | `CourseRepository.count()` |
| Enrollments | Count of all course enrollment rows. | `CourseEnrollmentRepository.count()` |
| Paid Orders | Count of orders with status `PAID`. | `OrderRepository.countByStatus(OrderStatus.PAID)` |
| Total Revenue | Sum of paid order item unit prices, all time. This matches the ANL-04 paid-order policy. | `OrderItemRepository.sumPaidRevenue(OrderStatus.PAID)` |
| New Students | Count of `STUDENT` users created in the selected date range. | `UserRepository.countByRoleAndCreatedAtGreaterThanEqualAndCreatedAtLessThan(...)` |
| Active Students | Distinct students with lesson progress activity in the selected date range, using `lastAccessedAt` with `lastUpdatedAt` fallback. | `LessonProgressRepository.countActiveStudentsForAnalytics(...)` |
| Student Growth chart | Daily new and active student trend for the selected range. | `UserRepository.findNewStudentEvents(...)`, `LessonProgressRepository.findActiveStudentEventsForAnalytics(...)` |
| Revenue Trend chart | Daily paid revenue and distinct paid order count for the selected range. | `OrderItemRepository.findPaidRevenueEvents(...)`, `OrderRepository.countByStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThan(...)` |

Counts that use joins already use distinct where needed: active students and chart paid order counts avoid duplicate students/orders from multi-row joins.

## Backend result

- No hard-coded, random, or mock production dashboard data was added.
- Existing dashboard backend already reads real repositories through `AdminAnalyticsService`.
- Revenue remains aligned with ANL-04: only `OrderStatus.PAID`, using paid order items.
- Empty DB returns zero values and does not throw.

## Frontend result

- KPI cards now keep the existing Admin layout/design system and include label, value, unit, and source/time description.
- KPI cards link to existing admin routes:
  - `/admin/users`
  - `/admin/users?role=STUDENT`
  - `/admin/users?role=TEACHER`
  - `/admin/courses`
  - `/admin/transactions`
  - `/admin/analytics`
  - `/admin/analytics/revenue`
- No fake percentage increase/decrease is displayed.
- Dashboard charts now have per-widget loading, empty, and error states.
- Dashboard data loading uses settled requests so one failed chart does not collapse the whole page.
- CSS changes are scoped to `static/css/admin/admin.css`; no global CSS was changed.

## Security result

- Spring Security remains enabled.
- `/admin/**` and `/api/admin/**` remain restricted to `ADMIN`.
- Admin can access dashboard.
- Teacher and Student are blocked from the dashboard page by the existing access-denied redirect to `/`.
- Teacher and Student are forbidden from admin analytics APIs.

## Tests run

Command:

```text
.\mvnw.cmd -q -Dtest=AdminAnalyticsControllerTest test
```

Result:

```text
Tests run: 11, Failures: 0, Errors: 0, Skipped: 0
```

Covered:

- Admin accesses dashboard page successfully.
- Teacher and Student are blocked from admin dashboard page.
- Non-admin users are blocked from admin analytics APIs.
- Anonymous user is unauthorized from admin dashboard API.
- Empty database returns zero KPI values.
- Seeded database returns expected KPI values.
- KPI values match repository counts.
- Revenue excludes pending, failed, cancelled, and refunded orders.
- Dashboard navigation links render to existing admin routes.

Compile command:

```text
.\mvnw.cmd -q -DskipTests compile
```

Result: success.

Additional check:

```text
node --check src\main\resources\static\js\admin\analytics.js
```

Result: success.

## Files changed for ANL-02

- `src/main/resources/templates/admin/dashboard.html`
- `src/main/resources/static/js/admin/analytics.js`
- `src/main/resources/static/css/admin/admin.css`
- `src/test/java/com/ojtsu26/elearning/controller/AdminAnalyticsControllerTest.java`
- `reports/06-anl-02-result.md`

Note: the worktree already contained unrelated modified teacher/ANL files before this report was written; they were not reverted or included in this ANL-02 scope.

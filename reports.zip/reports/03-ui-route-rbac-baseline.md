# 03 - UI, Route, RBAC Baseline for ANL/SYS

## Scope

Baseline reproduction only. No application source code, production password, database data, schema, branch, stash, reset, checkout, commit, or fix was performed.

Date/time: 2026-07-14, Asia/Bangkok.

Features:
- ANL-01: Teacher personal revenue analytics.
- ANL-02: Admin overview dashboard.
- ANL-03: Admin new and active students analytics.
- ANL-04: Admin revenue report.
- SYS-01: Admin system settings.

## Environment

- App: Spring Boot on `http://127.0.0.1:8080`.
- DB: local MySQL database `mock_project`.
- Browser/runtime: Chrome headless through DevTools Protocol.
- Viewports checked: `1440px`, `1024px`, `768px`, `390px`.

## Accounts Used

Existing seed accounts were used. No password was changed.

| Test role | Account |
|---|---|
| Anonymous | No login cookie |
| Student | `student0@elearning.com` |
| Teacher A | `teacher0@elearning.com` |
| Teacher B | `teacher1@elearning.com` |
| Admin | `admin0@elearning.com` |

Password used for seed accounts: `123456`.

## Routes Checked

| Feature | Page URLs | API URLs |
|---|---|---|
| ANL-01 | `/teacher/analytics` | `/api/teacher/analytics/revenue`, `/api/teacher/analytics/revenue/by-course` |
| ANL-02 | `/admin/dashboard` | `/api/admin/dashboard/overview`, plus student/revenue analytics APIs used by dashboard |
| ANL-03 | `/admin/analytics`, `/admin/statistics/students` | `/api/admin/analytics/students` |
| ANL-04 | `/admin/analytics/revenue`, `/admin/reports/revenue` | `/api/admin/analytics/revenue` |
| SYS-01 | `/admin/settings`, `/admin/system-settings` | `/api/admin/settings`, `/api/admin/settings/bulk` |

## Bugs Found

### UI-RBAC-001 - ANL-04 Revenue Report Has No Active Admin Sidebar Item

- Feature: ANL-04
- Role: Admin
- URL: `/admin/analytics/revenue`; also reproduced on `/admin/reports/revenue`
- Steps to reproduce:
  1. Login as `admin0@elearning.com`.
  2. Open `/admin/dashboard`.
  3. Click the dashboard `Open Report` link, or open `/admin/analytics/revenue` directly.
  4. Repeat at `1440px`, `1024px`, `768px`, and `390px`.
- Expected:
  - Revenue report opens with Admin layout.
  - Analytics/Reports menu item is active.
- Actual:
  - Page renders with Admin layout and data.
  - No sidebar item has the `active` class.
  - Browser measurement: `active: []` on all four viewports.
- HTTP status:
  - Admin direct page: `200`.
  - Anonymous direct page: `302 -> /auth/login`.
  - Student/Teacher direct page: `302 -> /`.
  - Admin API `/api/admin/analytics/revenue`: `200`.
  - Non-admin API: `401` anonymous, `403` student/teacher.
- Redirect:
  - Dashboard link redirects/navigates to `/admin/analytics/revenue`, final status `200`.
- Console/server error:
  - Browser console: no JavaScript error.
  - Server log: normal `GET /api/admin/analytics/revenue... Completed 200 OK`.
- Network request:
  - Initial load called `/api/admin/analytics/revenue?from=2026-06-15&to=2026-07-14&groupBy=day`.
  - Filter submit called `/api/admin/analytics/revenue?from=2026-06-01&to=2026-07-14&groupBy=day`.
- File suspected:
  - `src/main/resources/static/js/admin/admin.js`
  - `src/main/resources/templates/fragments/layout.html`
  - `src/main/resources/templates/admin/dashboard.html`
- Severity: Low

### UI-RBAC-002 - ANL-03 Alias URL Does Not Highlight Analytics Menu

- Feature: ANL-03
- Role: Admin
- URL: `/admin/statistics/students`
- Steps to reproduce:
  1. Login as `admin0@elearning.com`.
  2. Open `/admin/statistics/students` directly.
  3. Repeat at `1440px`, `1024px`, `768px`, and `390px`.
- Expected:
  - Student analytics page opens with Admin layout.
  - Analytics menu item is active, same as `/admin/analytics`.
- Actual:
  - Page renders with Admin layout and data.
  - No sidebar item has the `active` class.
  - Browser measurement: `active: []` on all four viewports.
- HTTP status:
  - Admin direct page: `200`.
  - Anonymous direct page: `302 -> /auth/login`.
  - Student/Teacher direct page: `302 -> /`.
  - Admin API `/api/admin/analytics/students`: `200`.
  - Non-admin API: `401` anonymous, `403` student/teacher.
- Redirect:
  - No redirect for Admin; final URL remains `/admin/statistics/students`.
- Console/server error:
  - Browser console: no JavaScript error.
  - Server log: normal analytics API mapping and `Completed 200 OK`.
- Network request:
  - Page called `/api/admin/analytics/students?from=2026-06-15&to=2026-07-14&groupBy=day`.
- File suspected:
  - `src/main/resources/static/js/admin/admin.js`
  - `src/main/resources/templates/fragments/layout.html`
  - `src/main/java/com/ojtsu26/elearning/controller/AdminViewController.java`
- Severity: Low

### UI-RBAC-003 - SYS-01 Alias URL Does Not Highlight Settings Menu

- Feature: SYS-01
- Role: Admin
- URL: `/admin/system-settings`
- Steps to reproduce:
  1. Login as `admin0@elearning.com`.
  2. Open `/admin/system-settings` directly.
  3. Repeat at `1440px`, `1024px`, `768px`, and `390px`.
- Expected:
  - Settings page opens with Admin layout.
  - Settings menu item is active, same as `/admin/settings`.
- Actual:
  - Page renders with Admin layout and settings data.
  - No sidebar item has the `active` class.
  - Browser measurement: `active: []` on all four viewports.
- HTTP status:
  - Admin direct page: `200`.
  - Anonymous direct page: `302 -> /auth/login`.
  - Student/Teacher direct page: `302 -> /`.
  - Admin API `/api/admin/settings`: `200`.
  - Non-admin API: `401` anonymous, `403` student/teacher.
- Redirect:
  - No redirect for Admin; final URL remains `/admin/system-settings`.
- Console/server error:
  - Browser console: no JavaScript error.
  - Server log: normal settings API mapping and `Completed 200 OK`.
- Network request:
  - Page called `/api/admin/settings`.
- File suspected:
  - `src/main/resources/static/js/admin/admin.js`
  - `src/main/resources/templates/fragments/layout.html`
  - `src/main/java/com/ojtsu26/elearning/controller/AdminViewController.java`
- Severity: Low

## Access and RBAC Results

| Scenario | Result |
|---|---|
| Anonymous opens protected pages | Blocked; page requests return `302 -> /auth/login` |
| Anonymous opens protected APIs | Blocked; JSON `401 {"code":401,"message":"Unauthorized access"}` |
| Student opens Teacher/Admin ANL/SYS pages | Blocked; page requests return `302 -> /` |
| Student opens Teacher/Admin ANL/SYS APIs | Blocked; JSON `403 {"code":403,"message":"Access denied"}` |
| Teacher opens Admin dashboard/analytics/settings | Blocked; page requests return `302 -> /`; APIs return `403` |
| Admin opens Teacher analytics page/API | Blocked; page request returns `302 -> /`; API returns `403`; no missing Teacher context 500 |
| Teacher A requests Teacher B course revenue | Blocked; `/api/teacher/analytics/revenue?courseId=1` and `/revenue/by-course?courseId=1` return `403 {"message":"You do not have access to this course."}` |

Server log notes:
- Wrong-role page access is logged by `CustomAccessDeniedHandler` as `Access denied error: Access Denied`.
- Anonymous page access is logged by `JwtAuthEntryPoint` as unauthorized.
- Teacher A requesting Teacher B course logs `BusinessException: You do not have access to this course.` and completes `403 FORBIDDEN`.
- No `500` server error was observed for the checked ANL/SYS routes.

## UI Rendering Results

| Feature | Valid role | Data render | Chart render | Table/form render | Viewport result |
|---|---|---|---|---|---|
| ANL-01 `/teacher/analytics` | Teacher A / Teacher B | Yes | `revenueTrendChart` rendered 30 bars | Course table rendered on desktop/tablet; mobile table hidden with responsive cards | No overflow/cut/overlap found |
| ANL-02 `/admin/dashboard` | Admin | Yes | `dashboardStudentsChart` and `dashboardRevenueChart` rendered 30 bars | KPI cards rendered | No overflow/cut/overlap found |
| ANL-03 `/admin/analytics` | Admin | Yes | `adminStudentsChart` rendered 30 bars | Trend table rendered 30 rows | No overflow/cut/overlap found |
| ANL-04 `/admin/analytics/revenue` | Admin | Yes | `adminRevenueChart` rendered 30 bars | Revenue table rendered 30 rows | No overflow/cut/overlap found |
| SYS-01 `/admin/settings` | Admin | Yes | Not applicable | Settings form rendered | No overflow/cut/overlap found |

Checks performed at `1440px`, `1024px`, `768px`, and `390px`:
- Header/sidebar did not cover page content in the measured routes.
- Cards did not overlap.
- Charts were not blank and were not cut by viewport width.
- Tables did not overflow viewport width.
- No `null`, `undefined`, or `NaN` was visible in body text.
- No feature-critical JavaScript error was captured.
- Filter submits sent network requests on ANL-01, ANL-02, ANL-03, and ANL-04.

## Navigation Results

| Feature | Navigation path | Result |
|---|---|---|
| ANL-01 | `/teacher/dashboard` -> sidebar `#nav-teacher-analytics` | Final `/teacher/analytics`, status `200`, active `nav-teacher-analytics` |
| ANL-02 | `/admin/analytics` -> sidebar `#nav-admin-dashboard` | Final `/admin/dashboard`, status `200`, active `nav-admin-dashboard` |
| ANL-03 | `/admin/dashboard` -> sidebar `#nav-admin-reports` | Final `/admin/analytics`, status `200`, active `nav-admin-reports` |
| ANL-04 | `/admin/dashboard` -> dashboard `Open Report` link | Final `/admin/analytics/revenue`, status `200`, active menu missing |
| SYS-01 | `/admin/dashboard` -> sidebar `#nav-admin-settings` | Final `/admin/settings`, status `200`, active `nav-admin-settings` |

## Filter Network Results

| Feature | Filter action result |
|---|---|
| ANL-01 | Submit sent `/api/teacher/analytics/revenue?from=2026-06-01&to=2026-07-14&groupBy=day` and `/api/teacher/analytics/revenue/by-course?from=2026-06-01&to=2026-07-14` |
| ANL-02 | Submit sent `/api/admin/dashboard/overview`, `/api/admin/analytics/students`, and `/api/admin/analytics/revenue` with updated `from=2026-06-01` |
| ANL-03 | Submit sent `/api/admin/analytics/students?from=2026-06-01&to=2026-07-14&groupBy=day` |
| ANL-04 | Submit sent `/api/admin/analytics/revenue?from=2026-06-01&to=2026-07-14&groupBy=day` |

## Suspected Root Cause

The active-menu issues are consistent with exact pathname matching in:

- `src/main/resources/static/js/admin/admin.js`

Current behavior only applies `active` when the sidebar link pathname equals `window.location.pathname`. Alias/report URLs such as `/admin/statistics/students`, `/admin/analytics/revenue`, `/admin/reports/revenue`, and `/admin/system-settings` do not exactly match the sidebar links `/admin/analytics` or `/admin/settings`.

Relevant sidebar links:

- `src/main/resources/templates/fragments/layout.html`
  - `#nav-admin-reports` -> `/admin/analytics`
  - `#nav-admin-settings` -> `/admin/settings`

## Conclusion

Runtime baseline found no ANL/SYS data-rendering failure, chart failure, filter request failure, table overflow, role-layout mismatch, cross-teacher data leak, or missing admin Teacher-context crash.

The reproducible UI defects are active-menu state bugs on admin alias/report URLs, listed above. No code was changed.

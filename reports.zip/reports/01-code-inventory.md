# 01 - Code Inventory for ANL/SYS

## Scope

Inventory only. No source code, database, branch, stash, reset, checkout, commit, or deletion was performed.

Target features:
- ANL-01: Teacher personal revenue analytics.
- ANL-02: Admin system overview dashboard.
- ANL-03: Admin new and active student analytics.
- ANL-04: Admin revenue report by day/month/year.
- SYS-01: Admin general system settings.

## Search Scope

Searched:
- `src/main/java`
- `src/main/resources/templates`
- `src/main/resources/static/css`
- `src/main/resources/static/js`
- `src/test`
- `pom.xml`
- `src/main/resources/application.properties`

Not found:
- `src/main/resources/db`
- `src/main/resources/application.yml`

Keywords used:
- `analytics`, `dashboard`, `revenue`, `earning`, `income`, `payment`, `order`, `transaction`, `student`, `active`, `activity`, `progress`, `system setting`, `configuration`, `admin setting`

## Inventory Table

| Feature | Route | Role | Controller | Service | Repository | Template | JS/CSS | Test | Ghi chú |
|---|---|---|---|---|---|---|---|---|---|
| ANL-01 Teacher revenue page | `GET /teacher/analytics`, also under `/instructor/analytics` via class mapping | `TEACHER` by `SecurityConfig` `/teacher/**`, `/api/teacher/**`, `/instructor/**` | `TeacherViewController.analytics()` | `CourseService.findByInstructorId()` only for filter dropdown | `CourseRepository.findByInstructorId()` | `src/main/resources/templates/teacher/analytics.html` | `src/main/resources/static/js/teacher/analytics.js`, `src/main/resources/static/css/teacher/teacher.css` | `TeacherAnalyticsControllerTest`, `TeacherRevenueAnalyticsServiceTest` | Page is real and uses backend course list plus API-loaded data. |
| ANL-01 Teacher revenue API | `GET /api/teacher/analytics/revenue` | `TEACHER` | `TeacherAnalyticsRestController.revenue()` | `TeacherRevenueAnalyticsService`, `TeacherRevenueAnalyticsServiceImpl.getRevenueAnalytics()` | `OrderItemRepository`, `CourseRepository`, `CourseEnrollmentRepository` | JSON only | Called by `teacher/analytics.js` | `TeacherAnalyticsControllerTest`, `TeacherRevenueAnalyticsServiceTest` | Uses authenticated current teacher, validates date/groupBy, rejects other teacher course, counts only `OrderStatus.PAID`. |
| ANL-01 Teacher revenue by course API | `GET /api/teacher/analytics/revenue/by-course` | `TEACHER` | `TeacherAnalyticsRestController.revenueByCourse()` | `TeacherRevenueAnalyticsServiceImpl.getRevenueByCourse()` | `OrderItemRepository.findTeacherRevenueByCourse()`, `CourseEnrollmentRepository.countTeacherEnrollmentsByCourseForAnalytics()`, `CourseRepository.findByInstructorId()` | JSON only | Called by `teacher/analytics.js` | `TeacherRevenueAnalyticsServiceTest` | Includes owned courses with zero revenue. |
| ANL-02 Admin dashboard page | `GET /admin/dashboard` | `ADMIN` by `SecurityConfig` `/admin/**`, `/api/admin/**` | `AdminViewController.dashboard()` | Data is loaded through Admin Analytics API, not model attributes | API repositories below | `src/main/resources/templates/admin/dashboard.html` | `src/main/resources/static/js/admin/analytics.js`, `src/main/resources/static/css/admin/admin.css` | `AdminAnalyticsControllerTest` covers API | Page is real. Dashboard widgets call multiple APIs. |
| ANL-02 Admin dashboard overview API | `GET /api/admin/dashboard/overview` | `ADMIN` | `AdminAnalyticsRestController.dashboardOverview()` | `AdminAnalyticsService`, `AdminAnalyticsServiceImpl.getDashboardOverview()` | `UserRepository`, `CourseRepository`, `CourseEnrollmentRepository`, `OrderRepository`, `OrderItemRepository`, `LessonProgressRepository` | JSON only | Called by `admin/analytics.js` | `AdminAnalyticsControllerTest` | Uses real DB counts. Total revenue and paid order count are all-time while new/active students use selected period. |
| ANL-03 Admin student analytics page | `GET /admin/analytics`; alias `GET /admin/statistics/students` | `ADMIN` | `AdminViewController.analytics()`, `AdminViewController.studentStatistics()` | Data loaded by API | API repositories below | `src/main/resources/templates/admin/analytics.html` | `src/main/resources/static/js/admin/analytics.js`, `src/main/resources/static/css/admin/admin.css` | `AdminAnalyticsControllerTest` covers API | `/admin/statistics/students` returns `admin/analytics`, not `admin/student-statistics.html`. |
| ANL-03 Admin student analytics API | `GET /api/admin/analytics/students` | `ADMIN` | `AdminAnalyticsRestController.studentAnalytics()` | `AdminAnalyticsServiceImpl.getStudentAnalytics()` | `UserRepository.findNewStudentEvents()`, `LessonProgressRepository.findActiveStudentEventsForAnalytics()` | JSON only | Called by `admin/analytics.js` | `AdminAnalyticsControllerTest` | New student = `User.role == STUDENT` by `createdAt`. Active student = `LessonProgress.lastAccessedAt` with `lastUpdatedAt` fallback. |
| ANL-04 Admin revenue report page | `GET /admin/reports/revenue`; alias `GET /admin/analytics/revenue` | `ADMIN` | `AdminViewController.revenueReport()`, `AdminViewController.analyticsRevenueReport()` | Data loaded by API | API repositories below | `src/main/resources/templates/admin/revenue-report.html` | `src/main/resources/static/js/admin/analytics.js`, `src/main/resources/static/css/admin/admin.css` | `AdminAnalyticsControllerTest` covers API | Page is real. Dashboard link uses `/admin/analytics/revenue`. |
| ANL-04 Admin revenue analytics API | `GET /api/admin/analytics/revenue` | `ADMIN` | `AdminAnalyticsRestController.revenueAnalytics()` | `AdminAnalyticsServiceImpl.getRevenueAnalytics()` | `OrderItemRepository.findPaidRevenueEvents()`, `OrderItemRepository.sumPaidRevenueForPeriod()`, `OrderRepository.countByStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThan()` | JSON only | Called by `admin/analytics.js` | `AdminAnalyticsControllerTest` | Uses only `OrderStatus.PAID`; groups in service by day/month/year. |
| SYS-01 Admin settings page | `GET /admin/settings`; alias `GET /admin/system-settings` | `ADMIN` | `AdminViewController.settings()`, `AdminViewController.systemSettings()` | Data loaded by API | API repositories below | `src/main/resources/templates/admin/settings.html` | `src/main/resources/static/js/admin/settings.js`, `src/main/resources/static/css/admin/admin.css` | `AdminSettingsControllerTest` covers API | Page is real and dynamic. |
| SYS-01 Admin settings read API | `GET /api/admin/settings` | `ADMIN` | `AdminSettingsRestController.getSettings()` | `SystemSettingService`, `SystemSettingServiceImpl.findAll()` | `SystemSettingRepository`, `UserRepository` indirectly for updates | JSON only | Called by `admin/settings.js` | `AdminSettingsControllerTest` | `ensureDefaults()` seeds six DB settings if missing. |
| SYS-01 Admin single setting update API | `PUT /api/admin/settings/{key}` | `ADMIN` | `AdminSettingsRestController.updateSetting()` | `SystemSettingServiceImpl.update()` | `SystemSettingRepository`, `UserRepository` | JSON only | Not called by current `admin/settings.js` | `AdminSettingsControllerTest` | Real endpoint. Validates type/editable and records `updatedBy`. |
| SYS-01 Admin bulk settings update API | `POST /api/admin/settings/bulk` | `ADMIN` | `AdminSettingsRestController.updateSettings()` | `SystemSettingServiceImpl.updateBulk()` | `SystemSettingRepository`, `UserRepository` | JSON only | Called by `admin/settings.js` | No direct bulk test found; single update tested | Real endpoint. |
| SYS-01 old placeholder API | `PATCH /api/admin/system-settings` | `ADMIN` | `AdminActionController.updateSystemSettings()` | none | none | JSON placeholder | No current frontend caller found | Not found | Placeholder duplicate; returns "Update system settings placeholder - not yet implemented". |

## Controller and Method Details

### ANL-01

- Page controller: `src/main/java/com/ojtsu26/elearning/controller/TeacherViewController.java`
  - Class mapping: `@RequestMapping({"/teacher", "/instructor"})`
  - Method: `analytics(Model, CustomUserDetails)`
  - Route: `GET /teacher/analytics`, `GET /instructor/analytics`
  - Template: `teacher/analytics`
  - Model: `courses` from `courseService.findByInstructorId(currentTeacherId)`

- API controller: `src/main/java/com/ojtsu26/elearning/controller/api/TeacherAnalyticsRestController.java`
  - Class mapping: `@RequestMapping("/api/teacher/analytics")`
  - Methods:
    - `revenue(from, to, groupBy, courseId)` -> `GET /api/teacher/analytics/revenue`
    - `revenueByCourse(from, to, courseId)` -> `GET /api/teacher/analytics/revenue/by-course`

### ANL-02, ANL-03, ANL-04

- Page controller: `src/main/java/com/ojtsu26/elearning/controller/AdminViewController.java`
  - Class mapping: `@RequestMapping("/admin")`
  - Methods:
    - `dashboard()` -> `GET /admin/dashboard` -> `admin/dashboard`
    - `analytics()` -> `GET /admin/analytics` -> `admin/analytics`
    - `studentStatistics()` -> `GET /admin/statistics/students` -> `admin/analytics`
    - `revenueReport()` -> `GET /admin/reports/revenue` -> `admin/revenue-report`
    - `analyticsRevenueReport()` -> `GET /admin/analytics/revenue` -> `admin/revenue-report`

- API controller: `src/main/java/com/ojtsu26/elearning/controller/api/AdminAnalyticsRestController.java`
  - Class mapping: `@RequestMapping("/api/admin")`
  - Methods:
    - `dashboardOverview(from, to)` -> `GET /api/admin/dashboard/overview`
    - `studentAnalytics(from, to, groupBy)` -> `GET /api/admin/analytics/students`
    - `revenueAnalytics(from, to, groupBy)` -> `GET /api/admin/analytics/revenue`

### SYS-01

- Page controller: `src/main/java/com/ojtsu26/elearning/controller/AdminViewController.java`
  - `settings()` -> `GET /admin/settings` -> `admin/settings`
  - `systemSettings()` -> `GET /admin/system-settings` -> `admin/settings`

- API controller: `src/main/java/com/ojtsu26/elearning/controller/api/AdminSettingsRestController.java`
  - Class mapping: `@RequestMapping("/api/admin/settings")`
  - Methods:
    - `getSettings()` -> `GET /api/admin/settings`
    - `updateSetting(key, request, currentUser)` -> `PUT /api/admin/settings/{key}`
    - `updateSettings(request, currentUser)` -> `POST /api/admin/settings/bulk`

- Placeholder duplicate:
  - `src/main/java/com/ojtsu26/elearning/controller/AdminActionController.java`
  - `updateSystemSettings()` -> `PATCH /api/admin/system-settings`
  - No service/repository. Placeholder response only.

## Role Guard

Role guard is route-level in `src/main/java/com/ojtsu26/elearning/config/SecurityConfig.java`:

- `/teacher/**`, `/api/teacher/**`, `/instructor/**` -> `hasRole("TEACHER")`
- `/admin/**`, `/api/admin/**` -> `hasRole("ADMIN")`

No feature-specific `@PreAuthorize` annotations were found on these controllers.

## Service, Repository, Entity, DTO Map

### ANL-01

- Service:
  - `TeacherRevenueAnalyticsService`
  - `TeacherRevenueAnalyticsServiceImpl`
- Repositories:
  - `OrderItemRepository`: teacher revenue sum, paid order count, trend events, by-course revenue.
  - `CourseRepository`: owned courses, ownership validation.
  - `CourseEnrollmentRepository`: teacher enrollments and distinct students.
- Entities:
  - `User`
  - `Course`
  - `Order`
  - `OrderItem`
  - `CourseEnrollment`
- DTO:
  - `TeacherRevenueAnalyticsResponseDTO`
  - `TeacherRevenueByCourseResponseDTO`
  - `TeacherRevenueCourseDTO`
  - `TeacherRevenueTrendPointDTO`
- Projections:
  - `TeacherRevenueEventProjection`
  - `TeacherRevenueCourseProjection`
  - `TeacherEnrollmentCountProjection`

### ANL-02

- Service:
  - `AdminAnalyticsService`
  - `AdminAnalyticsServiceImpl`
- Repositories:
  - `UserRepository`
  - `CourseRepository`
  - `CourseEnrollmentRepository`
  - `OrderRepository`
  - `OrderItemRepository`
  - `LessonProgressRepository`
- Entities:
  - `User`
  - `Course`
  - `CourseEnrollment`
  - `Order`
  - `OrderItem`
  - `LessonProgress`
- DTO:
  - `AdminDashboardOverviewDTO`
  - Also uses student/revenue DTOs for dashboard charts through the same JS file.

### ANL-03

- Service:
  - `AdminAnalyticsServiceImpl.getStudentAnalytics()`
- Repositories:
  - `UserRepository.findNewStudentEvents()`
  - `LessonProgressRepository.findActiveStudentEventsForAnalytics()`
- Entities:
  - `User`
  - `LessonProgress`
  - `CourseEnrollment`
- DTO:
  - `AdminStudentAnalyticsDTO`
  - `AdminStudentAnalyticsPointDTO`
- Projection:
  - `AdminStudentEventProjection`

### ANL-04

- Service:
  - `AdminAnalyticsServiceImpl.getRevenueAnalytics()`
- Repositories:
  - `OrderItemRepository.findPaidRevenueEvents()`
  - `OrderItemRepository.sumPaidRevenueForPeriod()`
  - `OrderRepository.countByStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThan()`
- Entities:
  - `Order`
  - `OrderItem`
  - `Course`
- DTO:
  - `AdminRevenueAnalyticsDTO`
  - `AdminRevenueTrendPointDTO`
- Projection:
  - `AdminRevenueEventProjection`

### SYS-01

- Service:
  - `SystemSettingService`
  - `SystemSettingServiceImpl`
- Repositories:
  - `SystemSettingRepository`
  - `UserRepository`
- Entities:
  - `SystemSetting`
  - `User`
- DTO/request:
  - `SystemSettingResponseDTO`
  - `SystemSettingUpdateRequestDTO`
  - `SystemSettingsBulkUpdateRequestDTO`
- Enum:
  - `SystemSettingType`

## Flow Check

### ANL-01

Browser -> `GET /teacher/analytics` -> `TeacherViewController.analytics()` -> `CourseService.findByInstructorId()` -> `CourseRepository` -> DB -> model `courses` -> `teacher/analytics.html` -> `teacher/analytics.js` -> `GET /api/teacher/analytics/revenue` and `GET /api/teacher/analytics/revenue/by-course` -> `TeacherAnalyticsRestController` -> `TeacherRevenueAnalyticsServiceImpl` -> `OrderItemRepository`, `CourseRepository`, `CourseEnrollmentRepository` -> DB -> `TeacherRevenue*DTO` JSON -> JavaScript renders KPI, bar chart, course table/cards.

### ANL-02

Browser -> `GET /admin/dashboard` -> `AdminViewController.dashboard()` -> `admin/dashboard.html` -> `admin/analytics.js` -> `GET /api/admin/dashboard/overview`, `GET /api/admin/analytics/students`, `GET /api/admin/analytics/revenue` -> `AdminAnalyticsRestController` -> `AdminAnalyticsServiceImpl` -> repositories -> DB -> DTO JSON -> JavaScript renders overview cards and charts.

### ANL-03

Browser -> `GET /admin/analytics` or `GET /admin/statistics/students` -> `AdminViewController` -> `admin/analytics.html` -> `admin/analytics.js` -> `GET /api/admin/analytics/students` -> `AdminAnalyticsRestController.studentAnalytics()` -> `AdminAnalyticsServiceImpl.getStudentAnalytics()` -> `UserRepository` and `LessonProgressRepository` -> DB -> `AdminStudentAnalyticsDTO` JSON -> JavaScript renders KPI, trend chart, and table.

### ANL-04

Browser -> `GET /admin/reports/revenue` or `GET /admin/analytics/revenue` -> `AdminViewController` -> `admin/revenue-report.html` -> `admin/analytics.js` -> `GET /api/admin/analytics/revenue` -> `AdminAnalyticsRestController.revenueAnalytics()` -> `AdminAnalyticsServiceImpl.getRevenueAnalytics()` -> `OrderItemRepository` and `OrderRepository` -> DB -> `AdminRevenueAnalyticsDTO` JSON -> JavaScript renders KPI, trend chart, and table.

### SYS-01

Browser -> `GET /admin/settings` or `GET /admin/system-settings` -> `AdminViewController` -> `admin/settings.html` -> `admin/settings.js` -> `GET /api/admin/settings` -> `AdminSettingsRestController.getSettings()` -> `SystemSettingServiceImpl.findAll()` -> `ensureDefaults()` -> `SystemSettingRepository` -> DB -> `SystemSettingResponseDTO` JSON -> JavaScript renders grouped settings form.

On save:
Browser -> `admin/settings.js` -> `POST /api/admin/settings/bulk` -> `AdminSettingsRestController.updateSettings()` -> `SystemSettingServiceImpl.updateBulk()` -> `SystemSettingRepository` and `UserRepository` -> DB -> DTO JSON -> JavaScript re-renders settings and status message.

## Files Actually Used

### Backend

- `src/main/java/com/ojtsu26/elearning/controller/TeacherViewController.java`
- `src/main/java/com/ojtsu26/elearning/controller/api/TeacherAnalyticsRestController.java`
- `src/main/java/com/ojtsu26/elearning/controller/AdminViewController.java`
- `src/main/java/com/ojtsu26/elearning/controller/api/AdminAnalyticsRestController.java`
- `src/main/java/com/ojtsu26/elearning/controller/api/AdminSettingsRestController.java`
- `src/main/java/com/ojtsu26/elearning/service/TeacherRevenueAnalyticsService.java`
- `src/main/java/com/ojtsu26/elearning/service/impl/TeacherRevenueAnalyticsServiceImpl.java`
- `src/main/java/com/ojtsu26/elearning/service/AdminAnalyticsService.java`
- `src/main/java/com/ojtsu26/elearning/service/impl/AdminAnalyticsServiceImpl.java`
- `src/main/java/com/ojtsu26/elearning/service/SystemSettingService.java`
- `src/main/java/com/ojtsu26/elearning/service/impl/SystemSettingServiceImpl.java`
- `src/main/java/com/ojtsu26/elearning/repository/OrderItemRepository.java`
- `src/main/java/com/ojtsu26/elearning/repository/OrderRepository.java`
- `src/main/java/com/ojtsu26/elearning/repository/UserRepository.java`
- `src/main/java/com/ojtsu26/elearning/repository/CourseRepository.java`
- `src/main/java/com/ojtsu26/elearning/repository/CourseEnrollmentRepository.java`
- `src/main/java/com/ojtsu26/elearning/repository/LessonProgressRepository.java`
- `src/main/java/com/ojtsu26/elearning/repository/SystemSettingRepository.java`

### Frontend

- `src/main/resources/templates/teacher/analytics.html`
- `src/main/resources/templates/admin/dashboard.html`
- `src/main/resources/templates/admin/analytics.html`
- `src/main/resources/templates/admin/revenue-report.html`
- `src/main/resources/templates/admin/settings.html`
- `src/main/resources/templates/fragments/layout.html`
- `src/main/resources/static/js/teacher/analytics.js`
- `src/main/resources/static/js/admin/analytics.js`
- `src/main/resources/static/js/admin/settings.js`
- `src/main/resources/static/css/teacher/teacher.css`
- `src/main/resources/static/css/admin/admin.css`

## Placeholder or Legacy Files

- `src/main/resources/templates/admin/student-statistics.html`
  - Appears unused by current controller mapping.
  - Contains hard-coded values: `100`, `80`, `15`.
  - Contains `chart-placeholder`.
  - Current `GET /admin/statistics/students` returns `admin/analytics`, not this file.

- `src/main/resources/templates/admin/system-settings.html`
  - Appears unused by current controller mapping.
  - Contains static form values such as max upload size `10` and language options.
  - Current `GET /admin/system-settings` returns `admin/settings`, not this file.

- `src/main/java/com/ojtsu26/elearning/controller/AdminActionController.java`
  - `PATCH /api/admin/system-settings` is placeholder only.
  - Several unrelated admin CRUD endpoints in this controller also return placeholder messages.

## Mock or Hard-Coded Data Found

- `src/main/resources/templates/admin/student-statistics.html`
  - Hard-coded student stats: total `100`, active `80`, new this month `15`.

- `src/main/resources/templates/admin/system-settings.html`
  - Static settings form with value `10` and language options.

- `src/main/resources/static/js/teacher/analytics.js`
  - Formats money as `USD`.

- `src/main/resources/static/js/admin/analytics.js`
  - Formats money as `USD`.

- `src/main/java/com/ojtsu26/elearning/service/impl/SystemSettingServiceImpl.java`
  - Default setting data is seeded in code through `ensureDefaults()`. This is configuration default data, not analytics mock data.

- `src/main/resources/application.properties`
  - Contains payment gateway sandbox configuration and literal payment gateway key/secret values. This was also flagged in `reports/00-repository-status.md`.

## Route Existence and Navigation Findings

Existing routes:
- `/teacher/analytics`
- `/api/teacher/analytics/revenue`
- `/api/teacher/analytics/revenue/by-course`
- `/admin/dashboard`
- `/admin/analytics`
- `/admin/statistics/students`
- `/admin/reports/revenue`
- `/admin/analytics/revenue`
- `/api/admin/dashboard/overview`
- `/api/admin/analytics/students`
- `/api/admin/analytics/revenue`
- `/admin/settings`
- `/admin/system-settings`
- `/api/admin/settings`
- `/api/admin/settings/{key}`
- `/api/admin/settings/bulk`

Placeholder/legacy route:
- `/api/admin/system-settings` exists as `PATCH`, but is placeholder and not used by current SYS-01 frontend.

Routes implied by existing files but not mapped to those files:
- No controller returns `admin/student-statistics`.
- No controller returns `admin/system-settings`.

Navigation links:
- Admin sidebar links to `/admin/analytics` and `/admin/settings`.
- Admin dashboard "Open Report" links to `/admin/analytics/revenue`.
- Teacher sidebar links to `/teacher/analytics`.
- Teacher dashboard and profile link to `/teacher/analytics`.
- Admin profile links to `/admin/analytics` and `/admin/settings`.

`href="#"` findings:
- `fragments/layout.html` portal footer has placeholder links for Terms of Service, Privacy Policy, Institutional Access, Support.
- No feature-critical ANL/SYS navigation link to the target pages was found using `href="#"`.

## Frontend API URL Check

No wrong URL was found for the ANL/SYS frontend calls during static inspection:
- `teacher/analytics.js` calls `/api/teacher/analytics/revenue` and `/api/teacher/analytics/revenue/by-course`, both exist.
- `admin/analytics.js` calls `/api/admin/dashboard/overview`, `/api/admin/analytics/students`, and `/api/admin/analytics/revenue`, all exist.
- `admin/settings.js` calls `/api/admin/settings` and `/api/admin/settings/bulk`, both exist.

Potential functional note:
- `AdminSettingsRestController` also supports `PUT /api/admin/settings/{key}`, but current frontend uses only bulk save.

## Duplicate Functionality

- Admin settings has two paths for the same real page:
  - `/admin/settings`
  - `/admin/system-settings`

- Admin revenue report has two paths for the same real page:
  - `/admin/reports/revenue`
  - `/admin/analytics/revenue`

- Admin student analytics has two paths for the same real page:
  - `/admin/analytics`
  - `/admin/statistics/students`

- SYS settings API has one real controller and one placeholder duplicate:
  - Real: `AdminSettingsRestController` under `/api/admin/settings`
  - Placeholder: `AdminActionController.updateSystemSettings()` under `/api/admin/system-settings`

## Tests Found

- `src/test/java/com/ojtsu26/elearning/controller/TeacherAnalyticsControllerTest.java`
  - Verifies teacher revenue API only includes own paid orders.
  - Verifies other teacher course is forbidden.
  - Verifies student role forbidden.

- `src/test/java/com/ojtsu26/elearning/service/TeacherRevenueAnalyticsServiceTest.java`
  - Verifies paid revenue/trend, ownership rejection, non-teacher rejection, invalid date/groupBy rejection, zero-revenue courses.

- `src/test/java/com/ojtsu26/elearning/controller/AdminAnalyticsControllerTest.java`
  - Verifies admin dashboard totals, revenue excludes pending/failed/cancelled/refunded, student analytics grouping, teacher/student/anonymous access rejection.

- `src/test/java/com/ojtsu26/elearning/controller/AdminSettingsControllerTest.java`
  - Verifies admin settings read/defaults, single update, invalid type rejection, non-editable rejection, teacher/student/anonymous rejection.

No dedicated test was found for:
- Admin settings bulk save endpoint `/api/admin/settings/bulk`.
- Static frontend API URL correctness.
- Legacy placeholder templates being unreachable.

## Notes and Risks for Next Phase

- Revenue source of truth appears to be `OrderItem.unitPrice` joined to `Order.status == PAID`.
- Revenue grouping uses `Order.createdAt`, not a separate `paidAt` timestamp.
- `OrderStatus` includes `PENDING`, `PAID`, `FAILED`, `EXPIRED`, `CANCELLED`, `REFUNDED`; analytics services use only `PAID`.
- Active student definition is explicitly `LessonProgress.lastAccessedAt` with `lastUpdatedAt` fallback.
- Date filtering uses server default `LocalDate.now()` and `LocalDateTime` boundaries; no explicit timezone configuration was found in this inventory pass.
- CSS/JS charts are custom DOM bar charts, not Chart.js.
- `SecurityConfig` disables CSRF globally. This matters for SYS-01 write endpoints, but this report is inventory only.
- `src/main/resources/db` is absent and no Flyway/Liquibase reference was found in searched files.

# ANL-04 Result - Admin Revenue Analytics

## Scope

- Chi sua ANL-04 va dependency truc tiep.
- Khong sua SYS-01 trong buoc nay.

## Revenue policy

- Source of truth: `OrderItem.unitPrice` thong qua `OrderItem -> Order`.
- Transaction hop le: chi tinh `OrderStatus.PAID`.
- Refund policy: order da refund khong con o trang thai `PAID`, nen bi loai theo status hien co.
- Timestamp ghi nhan doanh thu: `Order.createdAt`, vi database hien tai khong co `paidAt`/`completedAt` rieng cho revenue recognition.
- Timezone: date filter duoc dien giai theo application zone `ZoneId.systemDefault()`.
- Join safety: doanh thu cong theo order item; so giao dich dung `count(distinct o.id)` de khong bi nhan ban khi mot order co nhieu item.

## Granularity

- `DAY`: group theo year/month/day tu `Order.createdAt`; range dung start-inclusive va next-day-exclusive.
- `MONTH`: group theo ca year va month, khong gom nham cung thang khac nam.
- `YEAR`: group theo year, dem distinct order.
- Gia tri khong hop le bi reject HTTP 400 voi message `groupBy must be day, month, or year.`
- `from > to` bi reject HTTP 400 voi message `Start date must be before or equal to end date.`
- Khoang khong co doanh thu tra ve bucket 0 hop ly.

## Consistency guarantee

- Backend aggregate revenue bang query database, khong load toan bo payment/order item ve Java de group.
- KPI `totalRevenue` va `paidOrderCount` duoc tinh lai tu chinh danh sach `trend`.
- Frontend chart va table cung render tu `trend`.
- Vi vay: tong KPI = tong cac diem chart = tong cac hang table.

## Files changed

- `src/main/java/com/ojtsu26/elearning/dto/response/AdminRevenueAnalyticsDTO.java`
- `src/main/java/com/ojtsu26/elearning/repository/OrderItemRepository.java`
- `src/main/java/com/ojtsu26/elearning/repository/projection/AdminRevenueBucketProjection.java`
- `src/main/java/com/ojtsu26/elearning/repository/projection/AdminRevenueEventProjection.java` deleted
- `src/main/java/com/ojtsu26/elearning/service/impl/AdminAnalyticsServiceImpl.java`
- `src/main/resources/templates/admin/revenue-report.html`
- `src/main/resources/static/js/admin/analytics.js`
- `src/test/java/com/ojtsu26/elearning/controller/AdminAnalyticsControllerTest.java`
- `reports/08-anl-04-result.md`

## Frontend result

- Trang admin revenue report co tong doanh thu, so giao dich hop le, bo loc ngay, lua chon ngay/thang/nam, chart, table, currency format, empty/loading/error state va nut reset filter.
- KPI card bo sung unit va mo ta source/period.
- Revenue basis hien thi policy tinh doanh thu tu backend.
- Chart title hien thi khoang ngay va granularity dang xem.
- Table va chart dung cung data source `trend`.

## Tests

Da bo sung coverage trong `AdminAnalyticsControllerTest` cho:

- Group by day.
- Group by month co year.
- Group by year.
- Cuoi ngay.
- Cuoi thang.
- Cuoi nam.
- Pending/failed/refunded khong duoc tinh.
- Date range rong.
- `from > to`.
- Granularity sai.
- Nhieu order item khong nhan ban transaction.
- Non-admin access bi chan.
- KPI/chart/table consistency.

## Verification

- `node --check src\main\resources\static\js\admin\analytics.js`: passed.
- `.\mvnw.cmd -q -Dtest=AdminAnalyticsControllerTest test`: passed, 25 tests, 0 failures, 0 errors.
- `.\mvnw.cmd -q -DskipTests compile`: passed.

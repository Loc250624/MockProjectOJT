# 11 - Security / RBAC Review

Ngay kiem tra: 2026-07-14

Pham vi:
- ANL-01: `/teacher/analytics`, `/api/teacher/analytics/revenue`, `/api/teacher/analytics/revenue/by-course`
- ANL-02: `/admin/dashboard`, `/api/admin/dashboard/overview`
- ANL-03: `/admin/analytics`, `/api/admin/analytics/students`
- ANL-04: `/admin/analytics/revenue`, `/api/admin/analytics/revenue`
- SYS-01: `/admin/settings`, `/admin/system-settings`, `/api/admin/settings`, `/api/admin/settings/{key}`, `/api/admin/settings/bulk`

Nguyen tac:
- Khong them tinh nang moi.
- Khong kiem thu pha hoai hoac xoa du lieu live.
- Cac test ghi du lieu chi chay tren H2 in-memory test database.

## Tong quan ket qua

| Hang muc | Ket qua | Ghi chu |
|---|---|---|
| Authentication anonymous page/API | PASS | Anonymous page bi redirect login; anonymous API nhan 401. |
| Session het han | PASS | Duoc cover bang unauthenticated request trong MockMvc; khong test timeout session thuc te bang browser. |
| Authorization Student | PASS | Student bi chan khoi Teacher analytics, Admin analytics/dashboard, System settings. |
| Authorization Teacher | PASS | Teacher chi vao duoc ANL-01 cua chinh minh; bi chan ANL-02, ANL-03, ANL-04, SYS-01. |
| Authorization Admin | PASS | Admin vao duoc ANL-02, ANL-03, ANL-04, SYS-01; khong phu thuoc teacher context. |
| IDOR | PASS | Teacher context lay tu principal; courseId khac teacher bi 403; tham so teacherId/userId/orderId khong mo rong scope. |
| Input validation | PASS | Date sai format, granularity sai, SQL-like filter, HTML/script string, setting key sai, value qua dai, number out of range deu bi chan. |
| SYS-01 CSRF-style guard | PASS | Request hop le co verification header thanh cong; thieu header bi 403; sai role bi 403/redirect. |
| Spring Security CSRF token | NOT APPLICABLE | Ung dung dang disable Spring CSRF token; SYS-01 dang dung `X-Requested-With: XMLHttpRequest` guard thay the. |
| Secret trong HTML/JS/JSON/log code/diff | PASS | Khong thay secret thuc trong template/JS; JSON khong expose setting secret khong whitelist; log code khong ghi old/new value. |
| Browser network secret | NOT TESTED | Khong co browser/live backend network capture trong turn nay. |
| Runtime server log secret | NOT TESTED | Chi review static logging code va test output, khong co log server live. |

Khong con FAIL sau khi sua.

## Loi UI/security regression tim thay va da sua

| ID | Ket qua ban dau | Sua toi thieu | File |
|---|---|---|---|
| SEC-11-01 | FAIL - malformed `LocalDate` param tra 500 thay vi 400 tren analytics API. | Them handler `MethodArgumentTypeMismatchException` tra 400. | `src/main/java/com/ojtsu26/elearning/exception/GlobalExceptionHandler.java` |
| SEC-11-02 | FAIL - SYS-01 chap nhan string value co HTML/script markup. | Chan `<` va `>` trong STRING setting value. | `src/main/java/com/ojtsu26/elearning/service/impl/SystemSettingServiceImpl.java` |
| SEC-11-03 | NOT TESTED - SYS-01 page alias `/admin/system-settings` chua co regression coverage. | Mo rong test page RBAC cho `/admin/settings` va `/admin/system-settings`. | `src/test/java/com/ojtsu26/elearning/controller/AdminSettingsControllerTest.java` |

## Authentication

| Case | Ket qua | Bang chung |
|---|---|---|
| Anonymous vao `/teacher/analytics` | PASS | Redirect login trong `TeacherAnalyticsControllerTest`. |
| Anonymous goi `/api/teacher/analytics/revenue` | PASS | 401 trong `TeacherAnalyticsControllerTest`. |
| Anonymous vao `/admin/dashboard`, `/admin/analytics`, `/admin/analytics/revenue` | PASS | Redirect `/auth/login` trong `AdminAnalyticsControllerTest`. |
| Anonymous goi `/api/admin/dashboard/overview`, `/api/admin/analytics/students`, `/api/admin/analytics/revenue` | PASS | 401 trong `AdminAnalyticsControllerTest`. |
| Anonymous vao `/admin/settings`, `/admin/system-settings` | PASS | Redirect `/auth/login` trong `AdminSettingsControllerTest`. |
| Anonymous goi `/api/admin/settings` | PASS | 401 trong `AdminSettingsControllerTest`. |
| Session het han | PASS | Equivalent unauthenticated request duoc cover; timeout thuc te khong mo browser nen khong test rieng. |

## Authorization

| Role | Case | Ket qua | Bang chung |
|---|---|---|---|
| Student | Khong duoc truy cap Teacher revenue | PASS | Page redirect/API 403 trong `TeacherAnalyticsControllerTest`. |
| Student | Khong duoc truy cap Admin dashboard/analytics/settings | PASS | Admin analytics API/page va settings API/page tests. |
| Teacher | Duoc xem ANL-01 cua chinh minh | PASS | Teacher revenue tests dung principal hien tai. |
| Teacher | Khong duoc vao ANL-02/03/04 | PASS | Admin analytics page redirect `/`, API 403. |
| Teacher | Khong duoc vao SYS-01 | PASS | Settings API 403, page redirect `/`. |
| Teacher A | Khong xem duoc data Teacher B | PASS | `courseId` cua teacher khac bi 403; revenue tach theo teacher. |
| Admin | Duoc vao ANL-02/03/04/SYS-01 | PASS | Admin page/API tests pass. |
| Admin | Khong loi do thieu Teacher context | PASS | Admin analytics/settings service khong require teacher principal; tests pass. |

## IDOR va input

| Vector | Ket qua | Ghi chu |
|---|---|---|
| `teacherId` query | PASS | Endpoint teacher analytics bo qua query nay, lay teacher tu principal. |
| `userId` query | PASS | Khong lam doi scope response. |
| `courseId` query | PASS | Course khac owner bi 403. |
| `orderId` query | PASS | Khong lam doi scope response. |
| Filter parameter SQL-like | PASS | `groupBy=day;DROP TABLE users` bi 400. |
| API path variable | PASS | SYS-01 `{key}` bat buoc nam trong whitelist; key khong hop le bi 400. |
| HTML/script string | PASS | Bad date HTML bi 400; setting value co `<script>` bi 400. |
| Date sai dinh dang | PASS | Type mismatch tra 400, khong con 500. |
| Granularity sai | PASS | `groupBy` ngoai `day/month/year` bi 400. |
| Setting value qua dai | PASS | `site.name` > 120 chars bi 400. |
| Number ngoai range | PASS | Decimal range setting bi validate min/max. |

## CSRF / change request SYS-01

| Case | Ket qua | Ghi chu |
|---|---|---|
| PUT `/api/admin/settings/{key}` hop le | PASS | Admin + `X-Requested-With: XMLHttpRequest` update thanh cong. |
| POST `/api/admin/settings/bulk` hop le | PASS | Admin + verification header update thanh cong. |
| Thieu verification header | PASS | PUT va POST bulk tra 403. |
| Sai role | PASS | Teacher/Student khong update duoc settings. |
| Spring CSRF token thuc | NOT APPLICABLE | `SecurityConfig` dang disable CSRF token global; khong thay doi trong scope nay de tranh doi behavior rong. |

## Secret review

| Noi kiem tra | Ket qua | Ghi chu |
|---|---|---|
| HTML templates admin/teacher | PASS | `rg` secret patterns khong co match. |
| JavaScript admin/teacher | PASS | Khong co hard-coded payment secret; settings JS chi co password UI mode va request header. |
| JSON response settings | PASS | Test chen setting secret khong whitelist va assert key/value khong xuat hien. |
| Server log code | PASS | Log system setting chi ghi `key`, `sensitive`, `adminUserId`; khong ghi old/new value. |
| Git diff | PASS | Chi thay dummy secret string trong regression tests, dung de assert khong leak ra JSON. |
| Browser network | NOT TESTED | Khong capture browser network trong turn nay. |
| Runtime server log | NOT TESTED | Khong doc log server live. |

## File sua

- `src/main/java/com/ojtsu26/elearning/exception/GlobalExceptionHandler.java`
- `src/main/java/com/ojtsu26/elearning/service/impl/SystemSettingServiceImpl.java`
- `src/test/java/com/ojtsu26/elearning/controller/AdminAnalyticsControllerTest.java`
- `src/test/java/com/ojtsu26/elearning/controller/TeacherAnalyticsControllerTest.java`
- `src/test/java/com/ojtsu26/elearning/controller/AdminSettingsControllerTest.java`
- `reports/11-security-rbac-review.md`

## Test da chay

```text
.\mvnw.cmd "-Dtest=AdminAnalyticsControllerTest,TeacherAnalyticsControllerTest,AdminSettingsControllerTest" test
```

Ket qua:

```text
Tests run: 67, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```

## Loi con lai

| Hang muc | Ket qua | Ly do |
|---|---|---|
| Browser network secret capture | NOT TESTED | Khong mo live browser/backend trong turn nay. |
| Runtime server log secret capture | NOT TESTED | Khong co server log live de doi chieu. |
| Session timeout theo thoi gian thuc | NOT TESTED | MockMvc da cover unauthenticated/expired-equivalent request; timeout clock thuc chua test. |
| Spring CSRF token enforcement | NOT APPLICABLE | Ung dung hien dang disable Spring CSRF token va dung verification header rieng cho SYS-01. |

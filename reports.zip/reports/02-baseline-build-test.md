# 02 - Baseline Build and Test Report

## Scope

Baseline build/test only, before source-code fixes.

No source code, test code, database data/schema, branch, stash, reset, checkout, commit, or deletion was performed.

Input reports already present:
- `reports/00-repository-status.md`
- `reports/01-code-inventory.md`

## Commands Run

### Compile

Command:

```powershell
.\mvnw.cmd clean compile
```

Result:
- Status: `PASS`
- Exit code: `0`
- Maven result: `BUILD SUCCESS`
- Total time: `16.987 s`
- Finished at: `2026-07-14T09:15:36+07:00`

Important output:
- `Compiling 326 source files with javac [debug parameters release 17] to target\classes`
- `BUILD SUCCESS`

Warnings observed:
- MapStruct unmapped target property warnings in mapper files, including:
  - `CategoryMapper.java`
  - `SubmissionMapper.java`
  - `QuestionMapper.java`
  - `CertificateMapper.java`
  - `LessonMapper.java`
  - `CodingAssignmentMapper.java`
  - `TestcaseMapper.java`
  - `VideoMapper.java`
  - `RoadmapMapper.java`
  - `CourseEnrollmentMapper.java`
  - `QuizMapper.java`
  - `UserMapper.java`
  - `CourseMapper.java`
  - `TransactionMapper.java`
  - `LessonProgressMapper.java`
- Deprecated API warning in `BusinessDataSeeder.java`.
- Unchecked/unsafe operations warning in `MoMoProvider.java`.

Assessment:
- These are compile warnings, not compile errors.
- They do not block the next ANL/SYS baseline phase.

### Test

Command:

```powershell
.\mvnw.cmd test
```

Result:
- Status: `PASS`
- Exit code: `0`
- Maven result: `BUILD SUCCESS`
- Total time: `01:47 min`
- Finished at: `2026-07-14T09:17:30+07:00`

Important output:
- `Tests run: 225, Failures: 0, Errors: 0, Skipped: 0`
- `BUILD SUCCESS`

Surefire XML summary:
- Report files: `26`
- Total tests: `225`
- Passed: `225`
- Failed: `0`
- Errors: `0`
- Skipped: `0`

Per-test-class summary:

| Test class | Tests | Failures | Errors | Skipped |
|---|---:|---:|---:|---:|
| `VideoUtilsTest` | 5 | 0 | 0 | 0 |
| `AdminActionControllerTest` | 34 | 0 | 0 | 0 |
| `AdminAnalyticsControllerTest` | 6 | 0 | 0 | 0 |
| `AdminSettingsControllerTest` | 7 | 0 | 0 | 0 |
| `StudentActionControllerTest` | 3 | 0 | 0 | 0 |
| `StudentViewControllerTest` | 5 | 0 | 0 | 0 |
| `TeacherAnalyticsControllerTest` | 3 | 0 | 0 | 0 |
| `CertificateEligibilityServiceTest` | 6 | 0 | 0 | 0 |
| `CertificateServiceTest` | 6 | 0 | 0 | 0 |
| `CourseEnrollmentFrontendTemplateTest` | 6 | 0 | 0 | 0 |
| `CourseEnrollmentServiceTest` | 10 | 0 | 0 | 0 |
| `BlogCommentServiceImplTest` | 8 | 0 | 0 | 0 |
| `BlogPostServiceImplTest` | 15 | 0 | 0 | 0 |
| `CurrencyConversionServiceImplTest` | 8 | 0 | 0 | 0 |
| `ProfileOverviewServiceImplTest` | 2 | 0 | 0 | 0 |
| `UserServiceImplTest` | 9 | 0 | 0 | 0 |
| `MoMoProviderTest` | 5 | 0 | 0 | 0 |
| `NotificationServiceTest` | 8 | 0 | 0 | 0 |
| `OrderServiceTest` | 12 | 0 | 0 | 0 |
| `PaymentServiceTest` | 11 | 0 | 0 | 0 |
| `StudentAssessmentServiceTest` | 8 | 0 | 0 | 0 |
| `StudentLearningServiceTest` | 24 | 0 | 0 | 0 |
| `TeacherCourseStudentServiceTest` | 12 | 0 | 0 | 0 |
| `TeacherCourseStudentsTemplateTest` | 2 | 0 | 0 | 0 |
| `TeacherRevenueAnalyticsServiceTest` | 5 | 0 | 0 | 0 |
| `VnpayProviderTest` | 5 | 0 | 0 | 0 |

## Error Classification

| Category | Findings | Evidence | In ANL/SYS scope? | Blocks next work? |
|---|---|---|---|---|
| Compile error | None detected | `.\mvnw.cmd clean compile` ended with `BUILD SUCCESS` | No | No |
| Application context error | None detected | Spring Boot context tests completed successfully | No | No |
| Database connection error | None detected | Tests used H2 in-memory datasource and completed successfully | No | No |
| Repository query error | None detected | Repository-backed tests passed, including admin/teacher analytics tests | No | No |
| Security test error | None detected | Admin/teacher analytics/settings security tests passed | No | No |
| Controller test error | None detected | Controller test classes passed | No | No |
| Frontend/static resource error | None detected | Template/static-resource tests passed where present | No | No |
| Test failure unrelated to ANL/SYS | None detected | No failing tests | No | No |
| Environment or missing secret | None detected as blocker | Payment provider tests use mocked/test config and passed | No | No |

## Non-Failing Observations

- Test output is very large because Hibernate SQL/debug logs are enabled during tests.
- `MoMoProviderTest`, `PaymentServiceTest`, and `VnpayProviderTest` print some `ERROR`/`WARN` log lines for expected negative-path scenarios, but the tests pass.
- Surefire produced one dumpstream file:
  - `target/surefire-reports/2026-07-14T09-15-50_608.dumpstream`
  - Contents mention absolute classpath paths in the Boot Manifest-JAR and the hint `-Djdk.net.URLClassPath.disableClassPathURLCheck=true`.
  - This did not fail the test run and is not a blocker.

## ANL/SYS-Relevant Passing Coverage

- `AdminAnalyticsControllerTest`: `6/6` passed.
- `AdminSettingsControllerTest`: `7/7` passed.
- `TeacherAnalyticsControllerTest`: `3/3` passed.
- `TeacherRevenueAnalyticsServiceTest`: `5/5` passed.

## Conclusion

Baseline compile and tests are green.

There are no build/test blockers before starting the next ANL/SYS maintenance step. Existing compile warnings and verbose SQL logs should be treated as non-blocking baseline noise unless the next task specifically targets them.

## Final Numbers

- Compile: `PASS`
- Test: `PASS`
- Total tests: `225`
- Tests passed: `225`
- Tests failed: `0`
- Test errors: `0`
- Tests skipped: `0`
- Current blockers: none

# ANL-03 Result - Admin Student Analytics

Date: 2026-07-14

Scope: only ANL-03 and direct student-analytics dependencies were changed.

## Final metric definitions

### New students

Definition:

`new student = distinct User.id where User.role = STUDENT and User.createdAt is inside [from at 00:00, to + 1 day at 00:00)`

Reason:

- The root-cause report found no role-assignment history timestamp.
- The database has `Users.created_at`, and the existing implementation already used it.
- Users with role `ADMIN` or `TEACHER` are excluded even when their `createdAt` is inside the selected range.

### Active students

Definition:

`active student = distinct User.id where User.role = STUDENT and the user has LessonProgress activity inside [from at 00:00, to + 1 day at 00:00)`

Activity timestamp:

`coalesce(LessonProgress.lastAccessedAt, LessonProgress.lastUpdatedAt)`

Reason:

- No general activity/event log was found.
- No `lastLoginAt` field was found.
- Lesson progress is the best available production data source currently used by ANL-03.
- A student with multiple lesson progress rows is counted once per selected range and once per chart bucket.

Known limitation:

- This is a lesson-progress activity metric, not a complete platform activity metric.
- Students active only through quiz attempts, assignment submissions, enrollment creation, or login without lesson progress activity are not counted.
- `lastUpdatedAt` fallback may include updates to progress rows when no explicit `lastAccessedAt` is present.

Minimal future change if broader activity is required:

- Add a unified student activity event source for login, lesson access, quiz submit, assignment submit, and enrollment activity, then dedupe by student and bucket.
- No schema change was made for ANL-03 because the current requirement can be satisfied by documenting and tightening the existing real data source.

### Date and timezone policy

- API filters accept `LocalDate` values.
- Date ranges are normalized to whole days: start inclusive, next-day start exclusive.
- Default dates and response metadata use the application JVM time zone via `ZoneId.systemDefault()`.
- The API returns `timeZone` in `AdminStudentAnalyticsDTO`; the page displays it with the viewed range.

## Backend changes

- `LessonProgressRepository.countActiveStudentsForAnalytics(...)` now filters `p.enrollment.student.role = STUDENT`.
- `LessonProgressRepository.findActiveStudentEventsForAnalytics(...)` now filters `p.enrollment.student.role = STUDENT`.
- `AdminAnalyticsServiceImpl.getStudentAnalytics(...)` passes `Role.STUDENT` to active-student queries.
- `AdminStudentAnalyticsDTO` now includes `timeZone`.
- Existing validation remains: `from > to` throws `BusinessException(BAD_REQUEST)` and returns HTTP 400, not HTTP 500.
- Month grouping already keeps the year because buckets use `YearMonth.toString()` such as `2025-12`.

## Frontend changes

- Student Analytics page now shows:
  - New Students KPI
  - Active Students KPI
  - Viewed range
  - Time zone
  - Active-student definition
  - Trend chart
  - Filter date controls
  - Existing loading, empty, and error states
- KPI cards include unit and short definition text.
- The chart period uses the same `from` and `to` returned by the API.

## Tests

Command:

```text
.\mvnw.cmd -q -Dtest=AdminAnalyticsControllerTest test
```

Result:

```text
Tests run: 17, Failures: 0, Errors: 0, Skipped: 0
```

ANL-03 coverage added/verified:

- User without role `STUDENT` is not counted as new student.
- Student before selected date range is not counted.
- Student inside selected date range is counted.
- Student after selected date range is not counted.
- One student with multiple lesson progress activities is counted once.
- Non-student lesson progress activity is not counted as active student.
- Empty date range returns zero KPI values and zero chart bucket values.
- `from` greater than `to` returns HTTP 400, not HTTP 500.
- Inclusive start and exclusive next-day boundary are covered.
- Month grouping preserves year in bucket labels.
- Non-admin access to `/api/admin/analytics/students` is blocked.

Compile command:

```text
.\mvnw.cmd -q -DskipTests compile
```

Result: success.

Additional check:

```text
node --check src\main\resources\static\js\admin\analytics.js
```

Result: success.

## Files changed for ANL-03

- `src/main/java/com/ojtsu26/elearning/dto/response/AdminStudentAnalyticsDTO.java`
- `src/main/java/com/ojtsu26/elearning/repository/LessonProgressRepository.java`
- `src/main/java/com/ojtsu26/elearning/service/impl/AdminAnalyticsServiceImpl.java`
- `src/main/resources/templates/admin/analytics.html`
- `src/main/resources/static/js/admin/analytics.js`
- `src/main/resources/static/css/admin/admin.css`
- `src/test/java/com/ojtsu26/elearning/controller/AdminAnalyticsControllerTest.java`
- `reports/07-anl-03-result.md`

Note: the worktree already contained unrelated modified teacher/ANL files and earlier ANL-02 files. They were not reverted. This report describes the ANL-03 changes only.
